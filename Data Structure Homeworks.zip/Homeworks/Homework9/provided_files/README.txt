HOMEWORK 9:  PRIORITY QUEUES FOR MESH SIMPLIFICATION


NAME:  Shayne Preston


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

ALAC

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  25


ALGORITHM ANALYSIS: 
Assume v_0 vertices, e_0 edges, and t_0 triangles in the initial mesh,
reduced to t_final triangles using the -shortest criteria.  What is
the overall order notation for the program?  Analyze the separate
compoenents of the program to justify your answer.

ALGORITHM ANALYSIS -- LINEAR:

O(t_0+e_0+v_0) since there is no sorting with linear the run, the program has to check every triangle to see if it can be removed, and the three edges in it, and the three vertexes in that triangle.



ALGORITHM ANALYSIS -- PRIORITY QUEUE:

O(e_0+v_0) Since the queue is a tree of edges that need to be removed in order of length it only needs to check each edge if it can be removed and the two vertexes in it.



EXTRA CREDIT:  COLOR & OVERALL APPERANCE
Discuss the quality of your results in your README.txt and include
screenshots of your more impressive results.  If you have submitted
screenshots, give the file names and describe the results.



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

For some reason in my percolate_up and down it will think that the parent is larger
than the child even if there is a situation where it is not. Also my colapse is off
by a few triangles in some cases but working with ALAC I was unable to figure out
the issue.




