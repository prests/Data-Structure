HOMEWORK 1: MORPHOLOGICAL IMAGE PROCESSING


NAME:  Shayne Preston


COLLABORATORS AND OTHER RESOURCES:
 I worked with Henry Grover on file input and writing to a file.