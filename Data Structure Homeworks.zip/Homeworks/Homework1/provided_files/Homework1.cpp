#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include <cstring>
using namespace std;

void dilation(vector<string> &orig_grid, char new_char, char* fname) {
	ofstream myfile(fname);
	if(myfile.is_open()){
		for(int i=0; i<orig_grid.size(); ++i){
			for(int j=0; j<orig_grid[i].size(); ++j){
				//Checks above and below
				if(i!=0 && i!=orig_grid.size()-1) {
					if(orig_grid[i-1][j] == new_char || orig_grid[i+1][j] == new_char) {
						myfile << new_char;
						continue;
					}
				} else {
					if(i==0) {
						//Special case ie) top row or bottom row
						if(orig_grid[i+1][j] == new_char) {
							myfile << new_char;
							continue;
						}
					} else {
						if(i==orig_grid.size()-1) {
							if(orig_grid[i-1][j] == new_char){
								myfile << new_char;
								continue;
							}
						}
						}
					}
				//Checks left and right column
				if(j!=0 && j!=orig_grid[i].size()-1){
					if(orig_grid[i][j-1] == new_char || orig_grid[i][j+1] == new_char){
						myfile << new_char;
					} else {
						myfile << orig_grid[i][j];
					}
				} else {
					//Special case ie) all the way left or right
					if(j==0) {
						if(orig_grid[i][j+1] == new_char) {
							myfile << new_char;
						} else {
							myfile << orig_grid[i][j];
						}
					} else {
						if(j==orig_grid[i].size()-1) {
							if(orig_grid[i][j-1] == new_char) {
								myfile << new_char;
							} else {
								myfile << orig_grid[i][j];
							}
						} 
					}
				}
			}
			myfile << "\n";
		}
	}
	myfile.close();
}



void erosion(vector<string> &orig_grid, char old_char, char new_char, char* fname) {
	ofstream myfile(fname);
	if(myfile.is_open()){
		for(int i=0; i<orig_grid.size(); ++i) {
			int count = 0;
			for(int j=0; j<orig_grid[i].size(); ++j) {
				if(orig_grid[i][j] == old_char){
					int count = 0;
					//Checks above and below
					if(i!=0 && i!=orig_grid.size()-1){
						if(orig_grid[i-1][j] == old_char){
							++count;
						}
						if(orig_grid[i+1][j] == old_char) {
								++count;
						}
					} else {
						//Special case ei.) top row or bottom row
						if(i==0){
							cout << "i=0" << endl;
							if(orig_grid[i+1][j] == old_char) {
								++count;
							}
						} else {
							if(i==orig_grid.size()-1){
								if(orig_grid[i-1][j] == old_char) {
									++count;
								}
							}
						}
					//Checks left and right
					}
					if(j!=0 && j!=orig_grid[i].size()-1){
						if(orig_grid[i][j-1] == old_char){
							++count;
						}
						if(orig_grid[i][j+1] == old_char) {
							++count;
						}
					} else {
						//Special Case ie) far left or far right
						if(j==0){
							if(orig_grid[i][j+1] == old_char){
								++count;
							}
						} else {
							if(j==orig_grid[i].size()-1){
								if(orig_grid[i-1][j] == old_char) {
									++count;
								}
							}
						}
					}
					//Makes sure it is actually on the edge not inside a cluster
					if(count<4 && count>=1){
						myfile << new_char;
					} else {
						myfile << old_char;
					}
				} else {
					myfile << orig_grid[i][j];
				}
			}
			myfile << "\n";
		}
	}
	myfile.close();
}

void replace(vector<string> &orig_grid, char orig_char, char new_char, char* fname) {
	ofstream myfile(fname);
	if(myfile.is_open()){
		for(int i=0; i<orig_grid.size(); ++i) {
			//Creates string from line of string vector
			string line = orig_grid[i];
			char l[line.size()+1];
			strcpy(l, line.c_str());
			for(int j=0; j<line.size(); ++j) {
				if(l[j] == orig_char) {
					myfile << new_char;
				} else {
					myfile << l[j];
				}
			}
			myfile << "\n";
		}
	}
	myfile.close();
}

void floodfill(vector<string> &orig_grid, int x, int y, char new_char, char old) {
	/*
	Recurssion
	Changes char at (x,y) to new_char
	checks above, below, left, right
	if a side needs to have a char change it'll rerun the func with
	the point being needed to change as the new (x,y)
	*/
	orig_grid[x][y] = new_char;
	if(x!=0 && x!=orig_grid.size()){
		//Check above and below
		if(orig_grid[x-1][y] == old) {
			floodfill(orig_grid, x-1, y , new_char, old);
		}
		if(orig_grid[x+1][y] == old) {
			floodfill(orig_grid, x+1, y, new_char, old);
		}
	} else {
		//Special case ie) top or bottom row
		if(x==0){
			if(orig_grid[x+1][y] == old) {
				floodfill(orig_grid, x+1, y, new_char, old);
			}
		} else {
			if(x==orig_grid.size()){
				if(orig_grid[x-1][y] == old){
					floodfill(orig_grid, x-1, y, new_char, old);
				}
			}
		}
	}
	//Check left and right
	if(y!=0 && y!=orig_grid[x].size()){
		if(orig_grid[x][y-1] == old){
			floodfill(orig_grid, x, y-1, new_char, old);
		}
		if(orig_grid[x][y+1] == old){
			floodfill(orig_grid, x, y+1, new_char, old);
		}
	} else {
		//Special case ie) far left or far right
		if(y==0){
			if(orig_grid[x][y+1] == old){
				floodfill(orig_grid, x, y+1, new_char, old);
			}
		} else{
			if(y==orig_grid[x].size()){
				if(orig_grid[x][y-1] == old){
					floodfill(orig_grid, x, y-1, new_char, old);
				}
			}
		}
	}
}

int main(int argc, char* argv[]) {
	//Reads input file and adds lines to a string vector
	string line;
	ifstream myfile (argv[1]);
	vector<string> orig_grid;
	if(myfile.is_open()){
		while(getline(myfile,line) ) {
			orig_grid.push_back(line);
		}
		myfile.close();
	}
	//Determines which method to run
	if(string(argv[3]) == "replace"){
		char old_char = *argv[4];
		char new_char = *argv[5];
		char* fname = argv[2];
		replace(orig_grid, old_char, new_char, fname);
	} else{
		if(string(argv[3]) == "dilation") {
			char new_char = *argv[4];
			char* fname = argv[2];
			dilation(orig_grid, new_char, fname);	
		} else {
			if(string(argv[3]) == "erosion"){
				char old_char = *argv[4];
				char new_char = *argv[5];
				char* fname = argv[2];
				erosion(orig_grid, old_char, new_char, fname);
			} else{
				if(string(argv[3]) == "floodfill") {
					int x = atoi(argv[4]);
					int y = atoi(argv[5]);
					char new_char = *argv[6];
					char old = orig_grid[x][y];
					floodfill(orig_grid, x ,y , new_char, old);
					ofstream myfile(argv[2]);
					//Takes the reference of orig_grid to write it to output file
					if(myfile.is_open()){
						for(int i=0; i<orig_grid.size(); ++i){
							for(int j=0; j<orig_grid[i].size(); ++j){
								myfile << orig_grid[i][j];
							}
							myfile << "\n";
						}
					}
					myfile.close();
				} else {
					//**********************DEBUG
					cout << "***** We got to the end, oops";
				}
			}
		}
	} 
}

