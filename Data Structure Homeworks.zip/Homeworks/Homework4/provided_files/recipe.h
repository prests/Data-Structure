#include <list>
#include <string>
#include "ingredient.h"

//Creates Recipe
class Recipe{
	private:
		std::list<Ingredient> supplies_needed;
		std::string name;
	public:
		//Constructor
		Recipe(std::string aName);
		//Accessor
		std::string getName() const;
		std::list<Ingredient> getSupplies_needed() const;
		//Mutator
		void addIngredient(std::string aName, int aQuantity);
		void addFullIngredient(Ingredient i);
};
//sorts alphbetically 
bool sortRecipes(const Recipe &r1, const Recipe &r2);