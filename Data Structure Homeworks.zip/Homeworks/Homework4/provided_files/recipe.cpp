#include "recipe.h"
#include <list>
#include <string>
//Implements Recipe
Recipe::Recipe(std::string aName){
	name = aName;
	supplies_needed;
}

std::list<Ingredient> Recipe::getSupplies_needed() const{
	return supplies_needed;
}

std::string Recipe::getName() const{
	return name;
}

void Recipe::addIngredient(std::string aName, int aQuantity){
	Ingredient temp(aName, aQuantity);
	supplies_needed.push_back(temp);
}

void Recipe::addFullIngredient(Ingredient i){
	supplies_needed.push_back(i);
}

bool sortRecipes(const Recipe &r1, const Recipe &r2){
	if(r1.getName()<r2.getName()){
		return true;
	} else {return false;}
}