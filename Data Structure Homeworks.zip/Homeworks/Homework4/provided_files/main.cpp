//
// PROVIDED CODE FOR HOMEWORK 4: GROCERY LISTS
// 
// You may use none, a little, or all of this, as you choose, but we
// strongly urge you to examine it carefully.  You may modify this
// code as you wish to complete the assignment.
//


#include <cassert>
#include <cstdlib>
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

#include "kitchen.h"


// Helper functions
void readRecipe(std::istream &istr, std::ostream &ostr, std::list<Recipe> &recipes);
void addIngredients(std::istream &istr, std::ostream &ostr, Kitchen &kitchen);
void printRecipe(std::istream &istr, std::ostream &ostr, const std::list<Recipe> &recipes);
void makeRecipe(std::istream &istr, std::ostream &ostr, const std::list<Recipe> &recipes, Kitchen &kitchen);
void recipeSuggestions(std::ostream &ostr, const std::list<Recipe> &recipes, const Kitchen &kitchen);
void printIngredients(std::istream &istr, std::ostream &ostr, const Kitchen &kitchen);

// The main loop parses opens the files for I/O & parses the input
int main(int argc, char* argv[]) {

  // Check the number of arguments.
  if (argc != 3) {
    std::cerr << "Usage: " << argv[0] << " in-file out-file\n";
    return 1;
  }
  // Open and test the input file.
  std::ifstream istr(argv[1]);
  if (!istr) {
    std::cerr << "Could not open " << argv[1] << " to read\n";
    return 1;
  }
  // Open and test the output file.
  std::ofstream ostr(argv[2]);
  if (!ostr) {
    std::cerr << "Could not open " << argv[2] << " to write\n";
    return 1;
  }

  // the kitchen & recipe list
  Kitchen kitchen;
  std::list<Recipe> recipes;

  // some variables to help with parsing
  char c;
  while (istr >> c) {
    if (c == 'r') {
      // READ A NEW RECIPE
      readRecipe(istr,ostr,recipes);

    } else if (c == 'a') {
      // ADD INGREDIENTS TO THE KITCHEN
      addIngredients(istr,ostr,kitchen);
      
    } else if (c == 'p') {
      // PRINT A PARTICULAR RECIPE
      printRecipe(istr,ostr,recipes);

    } else if (c == 'm') {
      // MAKE SOME FOOD
      makeRecipe(istr,ostr,recipes,kitchen);

    } else if (c == 'k') {
      // PRINT THE CONTENTS OF THE KITCHEN
      printIngredients(istr,ostr,kitchen);

    } else if (c == 's') {
      // SUGGEST ALL RECIPES THAT CAN BE MADE INDIVIDUALLY FROM THE
      //   CURRENT CONTENTS OF THE KITCHEN
      recipeSuggestions(ostr,recipes,kitchen);

    } else if (c == 'd') {
      // EXTRA CREDIT: SUGGEST THE COLLECTION OF RECIPES THAT CAN BE
      // MADE TOGETHER THAT USE THE MAXIMUM NUMBER OF UNITS OF
      // INGREDIENTS
    } else if (c != ' ') {
      std::cerr << "unknown character: " << c << std::endl;
      exit(0);
    }
  }  
}


void readRecipe(std::istream &istr, std::ostream &ostr, std::list<Recipe> &recipes) {
  int units;
  int uneeded_int;
  std::string uneeded_string;
  std::string name, name2;  
  istr >> name;
  //Checks if recipe exists
  for(std::list<Recipe>::const_iterator it = recipes.begin(); it != recipes.end(); ++it){
	  if(it->getName() == name){
		  ostr << "Recipe for " << name << " already exists" << std::endl;
		  //dumps uneeded chars
		  while(1){
			  istr >> uneeded_int;
			  if(uneeded_int == 0) return;
			  istr >> uneeded_string;

		  }
	  }
  }
  // build the new recipe
  Recipe r(name);
  while (1) {
    istr >> units;
    if (units == 0) break;
    assert (units > 0);
    istr >> name2;
    r.addIngredient(name2,units);
  }
  // add it to the list
  recipes.push_back(r);
  ostr << "Recipe for " << name << " added" << std::endl;
}


void addIngredients(std::istream &istr, std::ostream &ostr, Kitchen &kitchen) {
  int units;
  std::string name;
  int count = 0;
  while (1) {
    istr >> units;
    if (units == 0) break;
    assert (units > 0);
    istr >> name;
	bool inlist = false;
	std::list<Ingredient> ingreds = kitchen.getSupplies();
		for(std::list<Ingredient>::iterator it = ingreds.begin(); it != ingreds.end(); ++it){
			//checks if same ingredient
			if(it->getName() == name){
				int temp = it->getQuantity()+units;
				it->changeQuantity(temp);
				inlist = true;
			}
		}
    
    // add the ingredients to the kitchen if not in
	if(inlist == false){
		kitchen.addIngredient(name,units);
	}
    count++;
  }
  //output
  if(count == 1){
	   ostr << count << " ingredient added to kitchen" << std::endl;
  } else{
	   ostr << count << " ingredients added to kitchen" << std::endl;
  }

}


void printRecipe(std::istream &istr, std::ostream &ostr, const std::list<Recipe> &recipes) {
  std::string name;
  istr >> name;
  bool inlist = false;
  std::list<Recipe> temp = recipes;
  std::list<Ingredient> tempadd;
  for(std::list<Recipe>::const_iterator it = temp.begin(); it!=temp.end(); ++it){
	  //checks if recipe exists
	  if(it->getName() == name){
		  inlist = true;
		  ostr << "To make " << name << ", mix together:\n";
		  std::list<Ingredient> supp = it->getSupplies_needed();
		  for(std::list<Ingredient>::const_iterator it2 = supp.begin(); it2!=supp.end(); ++it2){
			  if(it2->getQuantity()==1){
				Ingredient ing(it2->getName(),it2->getQuantity());
				tempadd.push_back(ing);	  
			  } else {
				Ingredient ing(it2->getName(),it2->getQuantity());
				tempadd.push_back(ing);
			  }
		  }
		  break;
	  }
  }
  //outputs
  if(inlist == true){
	  tempadd.sort(sortIngredients);
	  for(std::list<Ingredient>::const_iterator it= tempadd.begin(); it != tempadd.end(); ++it){
		  if(it->getQuantity()==1){
			  ostr << "  " << it->getQuantity() << " unit of " << it->getName() << "\n";
		  } else {
			  ostr << "  " << it->getQuantity() << " units of " << it->getName() << "\n";
		  }
	  }
  }
  //if doesn't exist
  if(inlist == false){
	  ostr << "No recipe for " << name << "\n";
  }
}


void makeRecipe(std::istream &istr, std::ostream &ostr, const std::list<Recipe> &recipes, Kitchen &kitchen) {
  std::string name;
  istr >> name;
  bool inlist = false;
  bool canMake = true;;
  int count = 0;
  std::list<Ingredient> tempCanMake;
  std::list<Ingredient> tempadd;
  std::list<Recipe> temp = recipes;
  for(std::list<Recipe>::const_iterator it = temp.begin(); it!=temp.end(); ++it){
	  //checks if recipe exists
	  if(it->getName() == name){
		  std::list<Ingredient> temp2 = it->getSupplies_needed();
		  for(std::list<Ingredient>::const_iterator it2 = temp2.begin(); it2 != temp2.end(); ++it2){
			  bool hasing= false;
			  inlist = true;
			  std::list<Ingredient> temp3 = kitchen.getSupplies();
			  for(std::list<Ingredient>::const_iterator it3 = temp3.begin(); it3 != temp3.end(); ++it3){
				  hasing = true;
				  //checks if ingredient exists
				  if(it2->getName() == it3->getName()){
					  //checks if has enough of ingredient
					  if(it2->getQuantity() > it3->getQuantity()){
						  if(count == 0){
							  ostr << "Cannot make " << name << ", need to buy:\n";
							  canMake = false;
							  ++count;
						  }
						  Ingredient ing(it2->getName(), it2->getQuantity()-it3->getQuantity());
						  tempadd.push_back(ing);	
					  } else {
						  //how much it would've needed
						  int num = it3->getQuantity()-it2->getQuantity();
						  Ingredient ing(it2->getName(), num);
						  tempCanMake.push_back(ing);
					  }
				  }
				}
				if(hasing == false){
					canMake = false;
				}
			  }
		  }
	  }
  
  //exists bu tnot enought
  if(canMake == false && inlist == true){
	tempadd.sort(sortIngredients);
	for(std::list<Ingredient>::const_iterator it = tempadd.begin(); it != tempadd.end(); ++it){
		if(it->getQuantity()==1){
			ostr << "  1 unit of " << it->getName() << "\n";
		} else { ostr << "  " << it->getQuantity() << "units of " << it->getName() << "\n";}
	}	  
  }
  //can make
  if(canMake == true && inlist == true){
	  ostr << "Made " << name << "\n";
	  std::list<Ingredient> temp_kitch = kitchen.getSupplies();
	  for(std::list<Ingredient>::iterator it = temp_kitch.begin(); it != temp_kitch.end(); ++it){
		  for(std::list<Ingredient>::const_iterator it2 = tempCanMake.begin(); it2 != tempCanMake.end(); ++it2){
			  if(it->getName() == it2->getName()){
				  int num = it2->getQuantity();
				  it->changeQuantity(num);
			  } 
		  }
	  }
	  kitchen.changeSupplies(temp_kitch);
	  
  }
  //doens't exist
  if(inlist == false){
	  ostr << "Don't know how to make " << name << "\n";
  }
}

void printIngredients(std::istream &istr, std::ostream &ostr, const Kitchen &kitchen){
	ostr  << "In the kitchen:\n";
	std::list<Ingredient> temp = kitchen.getSupplies();
	temp.sort(sortIngredients);
	//goes through all ingredients in kitchen
	for(std::list<Ingredient>::const_iterator it = temp.begin(); it!=temp.end(); ++it){
		if(it->getQuantity()==1){
			ostr << "  1 unit of " << it->getName() << "\n";
		} else {
			ostr << "  " << it->getQuantity() << " units of " << it->getName() << "\n";
		}
	}

}

void recipeSuggestions(std::ostream &ostr, const std::list<Recipe> &recipes, const Kitchen &kitchen) {
	std::list<Recipe> tempadd;
	for(std::list<Recipe>::const_iterator it = recipes.begin(); it!=recipes.end(); ++it){
		int count = 0;
		std::list<Ingredient> temprun = it->getSupplies_needed();
		for(std::list<Ingredient>::const_iterator it2 = temprun.begin(); it2!= temprun.end(); ++it2){
			bool hasingred = false;
			std::list<Ingredient> temp_kitch = kitchen.getSupplies();
			for(std::list<Ingredient>::const_iterator it3 = temp_kitch.begin(); it3!= temp_kitch.end(); ++it3){
				//checks if ingrients match and has enough
				if(it2->getName() == it3->getName() && it2->getQuantity() <= it3->getQuantity()){
					hasingred = true;
				}
			}
			if(hasingred == true){
				++count;
			}
		}
		//if all ingredients requirements are met
		if(count == it->getSupplies_needed().size()){
			Recipe temp(it->getName());
			std::list<Ingredient> temping = it->getSupplies_needed();
			for(std::list<Ingredient>::const_iterator it4 = temping.begin(); it4 != temping.end(); ++it4){
				Ingredient tempIngred(it4->getName(),it4->getQuantity());
				temp.addFullIngredient(tempIngred);
			}
			tempadd.push_back(temp);
		}
	}
	if(tempadd.size()==0){
		//no recipes to make
		ostr << "No recipes can be prepared\n";
	} else{
		ostr << "Recipes that can be prepared:\n";
	}
	//output
	tempadd.sort(sortRecipes);
	for(std::list<Recipe>::const_iterator it = tempadd.begin(); it!=tempadd.end(); ++it){
		ostr << "  " << it->getName() << "\n";
	}
}
