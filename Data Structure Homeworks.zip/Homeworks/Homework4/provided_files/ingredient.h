#include <string>
//creates ingredient
class Ingredient{
	private:
		std::string name;
		int quantity;
	public:
		//Constructor
		Ingredient(std::string aName, int quantity);
		//Accessor
		std::string getName() const;
		int getQuantity() const;
		//Mutator
		void changeQuantity(int aQuantity);
};
//sorts by quantity and alphabetically
bool sortIngredients(const Ingredient &i1, const Ingredient &i2);