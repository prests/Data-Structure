#include "kitchen.h"
#include <list>
#include <string>
//Implementation of kitchen
Kitchen::Kitchen(){
	
}

std::list<Ingredient> Kitchen::getSupplies() const{
	return supplies;
}

void Kitchen::addIngredient(std::string aName, int aQuantity){
	Ingredient temp(aName, aQuantity);
	supplies.push_back(temp);
}

void Kitchen::changeSupplies(std::list<Ingredient> aList){
	supplies = aList;
}