#include <list>
#include <string>
#include "recipe.h"

//Creates Kitchen
class Kitchen{
	private:
		std::list<Ingredient> supplies;
	public:
		//Constructor
		Kitchen();
		//Accessor
		std::list<Ingredient> getSupplies() const;
		//Mutator
		void addIngredient(std::string aName, int aQuantity);
		//Lets an old list to new list
		void changeSupplies(std::list<Ingredient> aList);
};