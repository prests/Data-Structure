#include "ingredient.h"
#include <string>
//Implements Ingredient
Ingredient::Ingredient(std::string aName, int aQuantity){
	name = aName;
	quantity = aQuantity;
}

std::string Ingredient::getName() const{
	return name;
}

int Ingredient::getQuantity() const{
	return quantity;
}

void Ingredient::changeQuantity(int aQuantity){
	quantity = aQuantity;
}

bool sortIngredients(const Ingredient &i1, const Ingredient &i2){
	if(i1.getQuantity() < i2.getQuantity()){
		return true;
	} else {
		if(i1.getQuantity() > i2.getQuantity()){
			return false;
		} else{
			if(i1.getName() < i2.getName()){
				return true;
			} else {
				return false;
			}
		}
	} 
}