#include "board.h"
#include <vector>
using namespace std;

Board::Board(){
	board;
	x_len = 0;
	y_len = 0;
	x_nums;
	y_nums;
}

Board::Board(int x, int y){
	board;
	board.resize(x, vector<char>(y, ' '));
	x_len = x;
	y_len = y;
	x_nums;
	y_nums;
}

void Board::add(const int& x, const int& y, const char& c){
	board[x][y] = c;
}

void Board::setsize(int x, int y){
	vector< vector<char> > temp(x, vector<char>(y, '\0'));
	board = temp;
	x_len = x;
	y_len = y;
	x_nums.reserve(x-2);
	y_nums.reserve(y-2);
}

void Board::add_x(int val){
	x_nums.push_back(val);
}

void Board::add_y(int val){
	y_nums.push_back(val);
}
int Board::x_size() const { return x_len; }
int Board::y_size() const { return y_len; }
vector< vector<char> > Board::return_board() const { return board; }	
vector<int> Board::return_x_nums() const { return x_nums; }
vector<int> Board::return_y_nums() const { return y_nums; }

