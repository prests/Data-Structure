#include <vector>
using namespace std;
class Board {
	public:
		Board();
		Board(int x, int y);
		int x_size() const;
		int y_size() const;
		vector< vector<char> > return_board() const;	
		vector<int> return_x_nums() const;
		vector<int> return_y_nums() const;
		
		void add(const int& x, const int& y, const char& c);
		void setsize(int x, int y);
		
		void add_x(int val);
		void add_y(int val);
		
	private:
		int x_len;
		int y_len;
		vector< vector<char> > board;
		vector<int> x_nums;
		vector<int> y_nums;
};

