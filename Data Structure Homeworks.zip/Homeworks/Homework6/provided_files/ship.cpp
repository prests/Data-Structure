#include "ship.h"

Ship::Ship(string aName){
	if(aName=="submarine"){ 
		name=aName;
		len=1;
	} 
	if(aName=="destroyer"){
		name=aName;
		len=2;
	} 
	if(aName=="cruiser"){
		name=aName;
		len=3;
	} 
	if(aName=="battleship"){
		name=aName;
		len=4;
	}
	if(aName=="carrier"){
		name=aName;
		len=5;
	} 
	if(aName=="cargo"){
		name=aName;
		len=6;
	}
	if(aName=="tanker"){
		name=aName;
		len=7;
	}
}
		
int Ship::get_len() const { return len; }
string Ship::get_name() const { return name; }
string Ship::get_direction() const { return direction; }
bool Ship::is_placed() const { return placed; }
int Ship::get_x() const { return x; }
int Ship::get_y() const { return y; }

void Ship::ship_placed(int aX, int aY) {
	placed = true;
	x = aX;
	y = aY;
}

void Ship::set_direction(string dir){
	direction = dir;
}

bool sorting(const Ship& s1, const Ship& s2){
	if(s1.get_len()>s2.get_len())
		return true;
	else
		return false;
}