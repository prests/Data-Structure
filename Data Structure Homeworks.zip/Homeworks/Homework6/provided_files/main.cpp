#include "board.h"
#include "ship.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

void print_board(Board& board){
	//print board using special format
	string temp = "";
	for(int i=0; i<board.x_size()-2; ++i){
		temp += "-";
	}
	cout << "+" << temp << "+" << endl;
	for(int i=1; i<board.y_size()-1; ++i){
		cout << "|";
		for(int j=1; j<board.x_size()-1; ++j){
			if(board.return_board()[j][i]!='\0')
				cout << board.return_board()[j][i];
			else
				cout << ' ';
		}
		cout << "|" << board.return_y_nums()[i-1] << endl;
	}
	cout << "+" << temp << "+" << endl;
	cout << " ";
	for(int i=0; i<board.x_size()-2; ++i){
		cout << board.return_x_nums()[i];
	}
	cout << endl;
}

void sort_ships(vector<Ship>& ships){
	//sort by size
	sort(ships.begin(), ships.end(), sorting);
}

bool checkaround(int x, int y, Board& board, Ship& ship, string direction){
	bool can_add = true;
	if(direction=="vertical"){
		//checks around for vertical
		if(y+ship.get_len()-1>board.y_size()-2) { return can_add=false; }
		for(int i=0; i<ship.get_len(); ++i){
			int count1 =0;
			int count2 =0;
			for(int j=1; j<board.y_size()-1; ++j){
				if(board.return_board()[x][j] != '\0')
					++count2;
			}
			for(int j=1; j<board.x_size()-1; ++j){
				if(board.return_board()[j][y+i] != '\0')
					++count1;
			}
			if(count2+ship.get_len()>board.return_x_nums()[x-1] || count1+1>board.return_y_nums()[y+i-1]) { return can_add=false;}
			if(board.return_board()[x][y+i]!='\0'){ return can_add=false;}
			if(i==0){
				if(board.return_board()[x-1][y-1]!='\0'){ return can_add=false;}
				if(board.return_board()[x][y-1]!='\0'){ return can_add=false;}
				if(board.return_board()[x+1][y-1]!='\0'){ return can_add=false;}
				if(board.return_board()[x-1][y]!='\0'){ return can_add=false;}
				if(board.return_board()[x+1][y]!='\0'){ return can_add=false;}
			}
			if(i==ship.get_len()-1){
				if(board.return_board()[x-1][y+i+1]!='\0'){ return can_add=false;}
				if(board.return_board()[x][y+i+1]!='\0'){ return can_add=false;}
				if(board.return_board()[x+1][y+i+1]!='\0'){ return can_add=false;}
				if(board.return_board()[x-1][y+i]!='\0'){ return can_add=false;}
				if(board.return_board()[x+1][y+i]!='\0'){ return can_add=false;}	
			} else {
				if(board.return_board()[x-1][y+i]!='\0'){ return can_add=false;}
				if(board.return_board()[x+1][y+i]!='\0'){ return can_add=false;}					
			}
		}
	}else{
		//checks around for horizontal
		if(x+ship.get_len()-1>board.x_size()-2){ return can_add=false;}
		for(int i=0; i<ship.get_len(); ++i){
			int count1 =0;
			int count2 =0;
			for(int j=1; j<board.y_size()-1; ++j){
				if(board.return_board()[x+i][j] != '\0')
					++count2;
			}
			for(int j=1; j<board.x_size()-1; ++j){
				if(board.return_board()[j][y] != '\0')
					++count1;
			}
			if(count2+1>board.return_x_nums()[x+i-1] || count1+ship.get_len()>board.return_y_nums()[y-1]) { return can_add=false;}
			if(i==0){
				if(board.return_board()[x-1][y-1]!='\0'){ return can_add=false;}
				if(board.return_board()[x-1][y]!='\0'){ return can_add=false;}
				if(board.return_board()[x-1][y+1]!='\0'){ return can_add=false;}
				if(board.return_board()[x][y-1]!='\0'){ return can_add=false;}
				if(board.return_board()[x][y+1]!='\0'){ return can_add=false;}
			}
			if(i==ship.get_len()-1){
				if(board.return_board()[x+i+1][y-1]!='\0'){ return can_add=false;}
				if(board.return_board()[x+i+1][y]!='\0'){ return can_add=false;}
				if(board.return_board()[x+i+1][y+1]!='\0'){ return can_add=false;}
				if(board.return_board()[x+i][y-1]!='\0'){ return can_add=false;}
				if(board.return_board()[x+i][y+1]!='\0'){ return can_add=false;}
			} else {
				if(board.return_board()[x+i][y-1]) { return can_add=false;}
				if(board.return_board()[x+i][y+1]) { return can_add=false;}
			}
		}
	}
	return can_add = true;;
}

bool checker(int x, int y, Board& board, Ship& ship){
	//checks if it can add
	if(!ship.is_placed()){
		if(checkaround(x, y, board, ship, "vertical")){
			ship.set_direction("vertical");
			return true;
		}
		if(checkaround(x, y, board, ship, "horizontal")){
			ship.set_direction("horizontal");
			return true;
		} else {
			return false;
		}
	}
}

void addpiece(Board& board, Ship& ship){
	//add method
	if(ship.get_direction()== "vertical"){
		if(ship.get_len()==1){
			board.add(ship.get_x(),ship.get_y(),'o');
		}else{
			board.add(ship.get_x(),ship.get_y(),'^');
			for(int i=0; i<ship.get_len()-2; ++i){
				board.add(ship.get_x(),ship.get_y()+i+1,'X');
			}
			board.add(ship.get_x(),ship.get_y()+ship.get_len()-1,'V');
		}
	} else{
		if(ship.get_len()==1){
			board.add(ship.get_x(),ship.get_y(),'o');
		} else {
			board.add(ship.get_x(),ship.get_y(),'<');
			for(int i=0; i<ship.get_len()-2; ++i){
				board.add(ship.get_x()+i+1,ship.get_y(),'X');
			}
			board.add(ship.get_x()+ship.get_len()-1,ship.get_y(),'>');
		}
	}
}

void finder(int x, int y, Board& board, vector<Ship>& ships, bool& solution){
	//finds an empty spot
	if(board.x_size()-2==x && board.y_size()-2==y){
		solution = false;
		return;
	} 
	if(board.return_board()[x][y]!='\0'){
		if(x != board.x_size()-2){
			finder(x+1,y,board,ships, solution);
			return;
		}else{
			finder(1,y+1,board,ships, solution);
			return;
		}
	} else{
		for(int i=0; i<ships.size(); ++i){
			if(!ships[i].is_placed()){
				if(checker(x,y,board,ships[i])){
					ships[i].ship_placed(x,y);
					addpiece(board,ships[i]);
					finder(1, 1, board, ships, solution);
					return;
				} else{
					if(x != board.x_size()-2){
						finder(x+1,y,board,ships, solution);
						return;
					}else{
						finder(1,y+1,board,ships, solution);
						return;
					}							
				}
			} 					
		}
		solution = true;
		return;
	}
}



int main(int argc, char* argv[]) {
	//imports file
	string temp;
	ifstream myfile (argv[1]);
	vector<string> file_info;
	vector<Ship> ships;
	Board board(1,3);
	while(myfile >> temp) {
		if(temp == "board"){
			int x;
			myfile >> x;
			x+=2;
			int y;
			myfile >> y;
			y+=2;
			board.setsize(x,y);
		}else{
			if(temp == "rows"){
				for(int i=0; i<board.x_size()-2; ++i){
					int val;
					myfile >> val;
					board.add_x(val);
				}
			}else{
				if(temp == "cols"){
					for(int i=0; i<board.y_size()-2; ++i){
						int val;
						myfile >> val;
						board.add_y(val);
					}
				} else {
					Ship temp_ship(temp);
					ships.push_back(temp_ship);
				}
			}
		}
	}
	print_board(board);
	sort_ships(ships);
	bool solution = true;
	finder(1, 1, board, ships, solution);
	//if solution found
	if(solution)
		print_board(board);
}	

	
