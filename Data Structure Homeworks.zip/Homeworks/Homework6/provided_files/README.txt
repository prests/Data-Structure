HOMEWORK 6: BATTLESHIP RECURSION


NAME:  Shayne Preston



COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

None

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  30



ANALYSIS OF PERFORMANCE OF YOUR ALGORITHM:
(order notation & concise paragraph, < 200 words)
The dimensions of the board (w and h) 
The number of ships (s)? 
The total number of occupied cells (o) or open water (w)? 
The number of constraints (c)? 
The number of unknown sums (u) or unspecified ship types (t)? 
Etc. 

O(w*h*s)


SUMMARY OF PERFORMANCE OF YOUR PROGRAM ON THE PROVIDED PUZZLES:
# of solutions & approximate wall clock running time for different
puzzles for a single solution or all solutions.

The puzzle checks each element in the grid and saw if it was empty. It then checked the
surrounding elements to see if there was no piece. I made an extra ring around the grid to avoid special
cases. If all was true it'd add it in either horizontally or vertically.

MISC. COMMENTS TO GRADER:  
(optional, please be concise!)

I was not able to solve some of the puzzles because the code checks to see if added vertically first then horizontally
if both cases are true in the short run then errors will occur later.
