#include <string>
using namespace std;

class Ship {
	private:
		string name;
		string direction;
		int len;
		bool placed;
		int x;
		int y;
	public:
		Ship(string aName);
		
		int get_len() const;
		string get_name() const;
		string get_direction() const;
		bool is_placed() const;
		int get_x() const;
		int get_y() const;
		
		void ship_placed(int aX, int aY);
		void set_direction(string dir);
};

bool sorting(const Ship& s1, const Ship& s2);