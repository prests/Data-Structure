#include "polygons.h"

std::string Polygon::getName() const{
	return name;
}

bool Polygon::HasAllEqualSides() const{
	double checker = 0;
	for(int i=0; i<vertices.size()-1; ++i){
		Vector tmp(vertices[i],vertices[i+1]);
		if(i==0)
			checker = tmp.Length();
		else{
			if(!EqualSides(tmp.Length(),checker))
				return false;
		}
	}
	return true;
}

bool Polygon::HasAllEqualAngles() const{
	double checker = Angle(vertices[vertices.size()-1],vertices[0],vertices[1]);
	for(int i=0; i<vertices.size()-2; ++i){
		if(i==vertices.size()-3){
			if(!EqualAngles(checker,Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return false;
			if(!EqualAngles(checker,Angle(vertices[i+1],vertices[i+2],vertices[0])))
				return false;
		}else{
			if(!EqualAngles(checker,Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return false;
		}
	}
	return true;
}

bool Polygon::HasARightAngle() const{
	for(int i=0; i<vertices.size()-2; ++i){
		if(i==vertices.size()-3){
			if(RightAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
			if(RightAngle(Angle(vertices[i+1],vertices[i+2],vertices[0])))
				return true;
			if(RightAngle(Angle(vertices[i+2],vertices[0],vertices[1])))
				return true;
		}else{
			if(RightAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
		}
	}
	return false;
}

bool Polygon::HasAnObtuseAngle () const{
	for(int i=0; i<vertices.size()-2; ++i){
		if(i==vertices.size()-3){
			if(ObtuseAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
			if(ObtuseAngle(Angle(vertices[i+1],vertices[i+2],vertices[0])))
				return true;
			if(ObtuseAngle(Angle(vertices[i+2],vertices[0],vertices[1])))
				return true;
		}else{
			if(ObtuseAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
		}
	}
	return false;
}

bool Polygon::HasAnAcuteAngle () const{
	for(int i=0; i<vertices.size()-2; ++i){
		if(i==vertices.size()-3){
			if(AcuteAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
			if(AcuteAngle(Angle(vertices[i+1],vertices[i+2],vertices[0])))
				return true;
			if(AcuteAngle(Angle(vertices[i+2],vertices[0],vertices[1])))
				return true;
		}else{
			if(AcuteAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
		}
	}
	return false;
}

bool Polygon::IsConcave() const{
	for(int i=0; i<vertices.size()-2; ++i){
		if(i==vertices.size()-3){
			if(ReflexAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
			if(ReflexAngle(Angle(vertices[i+1],vertices[i+2],vertices[0])))
				return true;
			if(ReflexAngle(Angle(vertices[i+2],vertices[0],vertices[1])))
				return true;
		}else{
			if(ReflexAngle(Angle(vertices[i],vertices[i+1],vertices[i+2])))
				return true;
		}
	}
	return false;
}

bool Polygon::IsConvex() const{
	if(IsConcave())
		return false;
	return true;
}