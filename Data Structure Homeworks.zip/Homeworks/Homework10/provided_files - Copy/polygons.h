#include <string>
#include <vector>

#include "utilities.h"

//Polygon class
class Polygon{
	public:
		Polygon(std::string aName, std::vector<Point> aVertices) : name(aName), vertices(aVertices) {
			if(vertices.size()<3)
				throw 1;//Not enough sides to be a polygon.
		}
		virtual ~Polygon(){
			vertices.clear();
		}
		
		//Accessors
		std::string getName() const;
		bool HasAllEqualSides() const;
		bool HasAllEqualAngles() const;
		bool HasARightAngle() const;
		bool HasAnObtuseAngle () const;
		bool HasAnAcuteAngle () const;
		bool IsConcave() const;
		bool IsConvex() const;
	protected:
		std::string name;
		std::vector<Point> vertices;
};

//Triangle class
class Triangle: public Polygon{
	public:
		Triangle(std::string aName, std::vector<Point> aVertices) : Polygon(aName, aVertices) {
			if(vertices.size()!=3)
				throw 1;//Incorrect number of sides.
		}
};

//Quadrilateral class
class Quadrilateral: public Polygon{
	public:
		Quadrilateral(std::string aName, std::vector<Point> aVertices) : Polygon(aName, aVertices) {
			if(vertices.size()!=4)
				throw 1;//Incorrect number of sides.
		}
};

//Obtuse Triangle class
class ObtuseTriangle: virtual public Triangle{
	public:
		ObtuseTriangle(std::string aName, std::vector<Point> aVertices) : Triangle(aName, aVertices) {
			if(!HasAnObtuseAngle())
				throw 1;//No obtuse angle.
		}
};

//Isosceles Triangle class
class IsoscelesTriangle: virtual public Triangle{
	public:
		IsoscelesTriangle(std::string aName, std::vector<Point> aVertices) : Triangle(aName, aVertices) {
			Vector tmp(vertices[0],vertices[1]);
			Vector tmp2(vertices[0],vertices[2]);
			Vector tmp3(vertices[1],vertices[2]);
			if(!EqualSides(tmp.Length(),tmp2.Length())){
				if(!EqualSides(tmp.Length(),tmp3.Length())){
					if(!EqualSides(tmp2.Length(),tmp3.Length()))
						throw 1;//No Equal Sides.
				}
			}
		}
};

//Right Triangle class
class RightTriangle: virtual public Triangle{
	public:
		RightTriangle(std::string aName, std::vector<Point> aVertices) : Triangle(aName, aVertices) {
			if(!HasARightAngle())
				throw 1;//No right angle.
		}
};

//Trapezoid class
class Trapezoid: virtual public Quadrilateral{
	public:
		Trapezoid(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices) {
			Vector tmp(vertices[0],vertices[1]);
			Vector tmp2(vertices[1],vertices[2]);
			Vector tmp3(vertices[2],vertices[3]);
			Vector tmp4(vertices[3],vertices[0]);
			int count = 0;
			if(Parallel(tmp,tmp3))
				++count;
			if(Parallel(tmp2,tmp4))
				++count;
			if(count<1)
				throw 1;//Incorrect number of paralell sides.
		}
};

//Kite class
class Kite: virtual public Quadrilateral{
	public:
		Kite(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices) {
			if(IsConcave())
				throw 1;//Has concave angle(s).
			Vector tmp(vertices[0],vertices[1]);
			Vector tmp2(vertices[1],vertices[2]);
			Vector tmp3(vertices[2],vertices[3]);
			Vector tmp4(vertices[3],vertices[0]);
			if(EqualSides(tmp.Length(),tmp2.Length())){
				if(!EqualSides(tmp.Length(),tmp2.Length()) || !EqualSides(tmp3.Length(),tmp4.Length()))
					throw 1;//Adjacent sides aren't equal.
			} else {
				if(!EqualSides(tmp.Length(),tmp4.Length()) || !EqualSides(tmp2.Length(),tmp3.Length()))
					throw 1;//Adjacent sides aren't equal.
			}
		}
};

//Arrow class
class Arrow: public Quadrilateral{
	public:
		Arrow(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices) {
			if(!IsConcave())
				throw 1;//No concave angle.
			Vector tmp(vertices[0],vertices[1]);
			Vector tmp2(vertices[1],vertices[2]);
			Vector tmp3(vertices[2],vertices[3]);
			Vector tmp4(vertices[3],vertices[0]);
			if(EqualSides(tmp.Length(),tmp2.Length())){
				if(!EqualSides(tmp.Length(),tmp2.Length()) || !EqualSides(tmp3.Length(),tmp4.Length()))
					throw 1;//Adjacent sides aren't equal.
			} else {
				if(!EqualSides(tmp.Length(),tmp4.Length()) || !EqualSides(tmp2.Length(),tmp3.Length()))
					throw 1;//Adjacent sides aren't equal.
			}
		}
};

//Isosceles Obtuse Triangle class
class IsoscelesObtuseTriangle: public ObtuseTriangle, public IsoscelesTriangle{
	public:
		IsoscelesObtuseTriangle(std::string aName, std::vector<Point> aVertices) : Triangle(aName, aVertices), ObtuseTriangle(aName, aVertices), IsoscelesTriangle(aName, aVertices) {}
};

//Equilateral Triangle class
class EquilateralTriangle: public IsoscelesTriangle{
	public:
		EquilateralTriangle(std::string aName, std::vector<Point> aVertices) : Triangle(aName, aVertices), IsoscelesTriangle(aName, aVertices) {
			if(!HasAllEqualSides())
				throw 1;//All sides aren't equal.
		}
};

//Isosceles Right Triangle class
class IsoscelesRightTriangle: public IsoscelesTriangle, public RightTriangle{
	public:
		IsoscelesRightTriangle(std::string aName, std::vector<Point> aVertices) : Triangle(aName, aVertices), IsoscelesTriangle(aName, aVertices), RightTriangle(aName, aVertices) {}
};

//Isosceles_Trapezoid class
class IsoscelesTrapezoid: virtual public Trapezoid{
	public:
		IsoscelesTrapezoid(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices), Trapezoid(aName, aVertices) {
			double angle1 = Angle(vertices[0],vertices[1],vertices[2]);
			double angle2 = Angle(vertices[1],vertices[2],vertices[3]);
			double angle3 = Angle(vertices[2],vertices[3],vertices[0]);
			double angle4 = Angle(vertices[3],vertices[0],vertices[1]);
			int count = 0;
			if(EqualAngles(angle1,angle2) && Parallel(Vector(vertices[1],vertices[2]),Vector(vertices[3],vertices[0])))
				++count;
			if(EqualAngles(angle2,angle3) && Parallel(Vector(vertices[2],vertices[3]),Vector(vertices[0],vertices[1])))
				++count;
			if(EqualAngles(angle3,angle4) && Parallel(Vector(vertices[3],vertices[0]),Vector(vertices[1],vertices[2])))
				++count;
			if(EqualAngles(angle4,angle1) && Parallel(Vector(vertices[0],vertices[1]),Vector(vertices[2],vertices[3])))
				++count;
			if(count<1)
				throw 1;//Incorrect number of equal angles.
		}
};

//Parallelogram class
class Parallelogram: virtual public Trapezoid{
	public:
		Parallelogram(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices), Trapezoid(aName, aVertices) {
			Vector tmp(vertices[0],vertices[1]);
			Vector tmp2(vertices[1],vertices[2]);
			Vector tmp3(vertices[2],vertices[3]);
			Vector tmp4(vertices[3],vertices[0]);
			if(!EqualSides(tmp.Length(),tmp3.Length()) || !EqualSides(tmp2.Length(),tmp4.Length()))
				throw 1;//1 or more pairs of non-equal sides.
		}
};

//Rectangle class
class Rectangle: public IsoscelesTrapezoid, virtual public Parallelogram{
	public:
		Rectangle(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices), Trapezoid(aName, aVertices), IsoscelesTrapezoid(aName, aVertices), Parallelogram(aName, aVertices) {
			if(!RightAngle(Angle(vertices[0],vertices[1],vertices[2])))
				throw 1;//1 or more none right angles.
			if(!RightAngle(Angle(vertices[1],vertices[2],vertices[3])))
				throw 1;//1 or more none right angles.
			if(!RightAngle(Angle(vertices[2],vertices[3],vertices[0])))
				throw 1;//1 or more none right angles.
			if(!RightAngle(Angle(vertices[3],vertices[0],vertices[1])))
				throw 1;//1 or more none right angles.			
		}
};

//Rhombus class
class Rhombus: virtual public Parallelogram, public Kite{
	public:
		Rhombus(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices), Trapezoid(aName, aVertices), Parallelogram(aName, aVertices), Kite(aName, aVertices) {
			Vector tmp(vertices[0],vertices[1]);
			Vector tmp2(vertices[1],vertices[2]);
			Vector tmp3(vertices[2],vertices[3]);
			Vector tmp4(vertices[3],vertices[0]);
		if(!EqualSides(tmp.Length(),tmp2.Length()) || !EqualSides(tmp.Length(),tmp3.Length()) || !EqualSides(tmp.Length(),tmp4.Length()))
			throw 1;//1 or more sides are not equal.
		}
};

//Square class
class Square: public Rectangle, public Rhombus{
	public:
		Square(std::string aName, std::vector<Point> aVertices) : Quadrilateral(aName, aVertices), Trapezoid(aName, aVertices), Parallelogram(aName, aVertices), Rectangle(aName, aVertices), Rhombus(aName, aVertices) {}
};
