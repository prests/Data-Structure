EXTRA CREDIT HOMEWORK: DEBUGGING

NAME:  Shayne Preston



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  4



GOAL:

A bright young coder named Lee
Wished to loop while i was 3
But when writing the =
He forgot its sequel
And thus looped infinitely


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(TAs, ALAC tutors, upperclassmen, students/instructor via LMS,
etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

none

Remember: All finding and fixing bugs for this assignment must be
done on your own, as described in "Academic Integrity for Homework"
handout.



EXTRA CREDIT:
List any bugs you found that did not or should not affect the normal execution
of the program. (These should also go in your writeup.)

-changed uint to int
-The # of argc as long as there were argc's
-various edits from +1 to ++ to make it more visually appealing
-spacing

MISC. COMMENTS TO GRADER:
Optional, please be concise!
