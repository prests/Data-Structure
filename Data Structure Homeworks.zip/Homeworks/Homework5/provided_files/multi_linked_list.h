#ifndef MultiLL_h_
#define MultiLL_h_

#include <cassert>
#include <cstdlib>
#include <string>
#include <iostream>
#include <ctime>
#include "mtrand.h"

//-----------------------------------------------
// NODE ClASS
template <class T>
class Node {
	public:
		Node() : chrono_next_(NULL), chrono_prev_(NULL), sorted_next_(NULL), sorted_prev_(NULL), random_next_(NULL) {}
		Node(const T& v) : value_(v), chrono_next_(NULL), chrono_prev_(NULL), sorted_next_(NULL), sorted_prev_(NULL), random_next_(NULL) {}
		
		// Variables
		T value_;
		Node<T>* chrono_next_;
		Node<T>* chrono_prev_;
		Node<T>* sorted_next_;
		Node<T>* sorted_prev_;
		Node<T>* random_next_;
};

//Forward declaration
template <class T> class MultiLL;

//------------------------------------------------
// List Iterator
template <class T>
class list_iterator {
	public:
		//constructors
		list_iterator() : ptr_(NULL), point_(NULL) {}
		list_iterator(Node<T>* p, std::string t, MultiLL<T>*q) : ptr_(p), type(t), point_(q) {}
		list_iterator(const list_iterator<T>& old) : ptr_(old.ptr_), type(old.type), point_(old.point_) {}
		list_iterator<T>& operator=(const list_iterator<T>& old){
		ptr_ = old.ptr_; type = old.type; point_ = old.point_; return *this; }
		~list_iterator() {}
		
		// dereferencer
		T& operator*() {return ptr_->value_; }
		
		//increment
		list_iterator<T>& operator++() {
			if(type == "chrono") {ptr_ = ptr_->chrono_next_;}
			if(type == "sorted") {ptr_ = ptr_->sorted_next_;}
			if(type == "random") {ptr_ = ptr_->random_next_;}
			return *this;
		}
		list_iterator<T> operator++(int) {
			list_iterator<T> temp(*this);
			if(type == "chrono") {ptr_ = ptr_->chrono_next_;}
			if(type == "sorted") {ptr_ = ptr_->sorted_next_;}
			if(type == "random") {ptr_ = ptr_->random_next_;}
			return temp;
		}
		
		//decrement
		list_iterator<T>& operator--() {
			if(type == "chrono") {
				if(ptr_ == NULL){ ptr_ = point_->chrono_tail_;}
				else { ptr_ = ptr_->chrono_prev_;}
			}
			else{
				if(ptr_ == NULL){ ptr_ = point_->sorted_tail_;}
				else { ptr_ = ptr_->sorted_prev_;}
			}
			return *this;
		}
		list_iterator<T> operator--(int) {
			list_iterator<T> temp(*this);
			if(type == "chrono") {ptr_ = ptr_->chrono_prev_;}
			if(type == "sorted") {ptr_ = ptr_->sorted_prev_;}
			return temp;
		}
		//give MultiLL private variables
		friend class MultiLL<T>;
		
		bool operator==(const list_iterator<T>& r) const {
			return ptr_ == r.ptr_; }
		bool operator!=(const list_iterator<T>& r) const {
		return ptr_ != r.ptr_; }

	private:
		//variables
		Node<T>* ptr_;
		std::string type;
		MultiLL<T>* point_;
		
};

//-------------------------------------------------------------------
// LIST CLASS
template <class T>
class MultiLL {
	public:
		friend class list_iterator<T>; 
		//constructors
		MultiLL() : mtrand_autoseed(time(NULL)), chrono_head_(NULL), chrono_tail_(NULL), sorted_head_(NULL), sorted_tail_(NULL), random_head_(NULL), size_(0), items_used(0) {}
		MultiLL(const MultiLL<T>& old) { this->copy_list(old); }
		MultiLL& operator= (const MultiLL<T>& old);
		~MultiLL() { this->destroy_list(); }
		
		//accessors & modifiers
		unsigned int size() const { return size_; }
		bool empty() const { return chrono_head_ == NULL; }
		void clear() { this->destroy_list(); }
		
		// read/write to contents (chrono)
		const T& chrono_front() const { return chrono_head_->value_; }
		T& chrono_front() { return chrono_head_->value_; }
		const T& chrono_back() const { return chrono_tail_->value_; }
		T& chrono_back() { return chrono_tail_->value_; }
		
		// read/write to contents (sorted)
		const T& sorted_front() const { return sorted_head_->value_; }
		T& sorted_front() { return sorted_head_->value_; }
		const T& sorted_back() const { return sorted_tail_->value_; }
		T& sorted_back() { return sorted_tail_->value_; }
		
		// read/write to contents (random)
		const T& random_front() const { return random_head_->value_; }
		T& random_front() { return random_head_->value_; }
		
		// add a Node
		void add(const T& v);
		
		// iterator
		typedef list_iterator<T> iterator;
		iterator erase(iterator itr);
		iterator insert(iterator itr, const T& v);
		iterator begin_chronological() { return iterator(chrono_head_, "chrono", this); }
		iterator begin_sorted() { return iterator(sorted_head_, "sorted", this); }
		iterator begin_random() { 
			items_used = 0;
			for(int i=0; i<1000000000; ++i){}
			MultiLL *temp_list = new MultiLL<T>();

			for(iterator iter = this->begin_chronological(); iter!=this->end_chronological(); ++iter){
				temp_list->add(*iter);
			}
			int temp = mtrand_autoseed() % (size_);
			int i = 0;
			iterator itr = temp_list->begin_chronological();
			while(i<temp){
				++itr;
				++i;
			}
			Node<T>* newp = new Node<T>(*itr);
			newp->random_next_ = NULL;
			random_head_ = newp;
			if(itr.ptr_ == temp_list->chrono_head_){
				temp_list->chrono_head_->chrono_next_->chrono_prev_ = NULL;
				temp_list->chrono_head_ = temp_list->chrono_head_->chrono_next_;
			} else if(itr.ptr_ == temp_list->chrono_tail_){
				temp_list->chrono_tail_->chrono_prev_->chrono_next_ = NULL;
				temp_list->chrono_tail_ = temp_list->chrono_tail_->chrono_prev_;
			} else {
				itr.ptr_->chrono_next_->chrono_prev_= itr.ptr_->chrono_prev_;
				itr.ptr_->chrono_prev_->chrono_next_= itr.ptr_->chrono_next_;
			}
			++items_used;
			Node<T>* holder = random_head_;
			while(items_used<size_){
				temp = mtrand_autoseed() % (size_-items_used);
				i = 0;
				itr = temp_list->begin_chronological();
				while(i<temp){
					++itr;
					++i;
				}
				newp = new Node<T>(*itr);
				if(items_used==size_-1){
					holder->random_next_ = newp;
					newp->random_next_= random_head_;
					newp = holder;
					break;
				}else{newp->random_next_ = NULL;}
				holder->random_next_ = newp;
				holder = newp;
				if(itr.ptr_ == temp_list->chrono_head_){
					temp_list->chrono_head_->chrono_next_->chrono_prev_ = NULL;
					temp_list->chrono_head_ = temp_list->chrono_head_->chrono_next_;
				} else if(itr.ptr_ == temp_list->chrono_tail_){
					temp_list->chrono_tail_->chrono_prev_->chrono_next_ = NULL;
					temp_list->chrono_tail_ = temp_list->chrono_tail_->chrono_prev_;
				} else {
					itr.ptr_->chrono_next_->chrono_prev_= itr.ptr_->chrono_prev_;
					itr.ptr_->chrono_prev_->chrono_next_= itr.ptr_->chrono_next_;					
				}
				++items_used;
			}
			temp_list->destroy_list();
			return iterator(random_head_, "random", this); 
		}
		iterator end_chronological() { return iterator(NULL, "chrono", this); }
		iterator end_sorted() { return iterator(NULL, "sorted", this); }
		
	private:
		//helper functions
		void copy_list(const MultiLL<T>& old);
		void destroy_list();
		
		//variables
		Node<T>* chrono_head_;
		Node<T>* chrono_tail_;
		Node<T>* sorted_head_;
		Node<T>* sorted_tail_;
		Node<T>* random_head_;
		MTRand_int32 mtrand_autoseed;
		unsigned int items_used;
		unsigned int size_;
};

//--------------------------------------------------------------------------------
// LIST CLASS IMPLEMENTATION
template <class T>
MultiLL<T>& MultiLL<T>::operator = (const MultiLL<T>& old) {
	// check for self-assignment
	if(&old != this){
		this->destroy_list();
		this->copy_list(old);
	}
	return *this;
}

template <class T>
void MultiLL<T>::add(const T&v){
	Node<T>* newp = new Node<T>(v);
	if(size_==0){
		chrono_head_=chrono_tail_=sorted_head_=sorted_tail_=random_head_= newp;
		++size_;
	} else {
		newp->chrono_next_ = NULL;
		newp->chrono_prev_ = chrono_tail_;
		chrono_tail_->chrono_next_ = newp;
		chrono_tail_ = newp;
		for(iterator itr = this->begin_sorted(); itr != this->end_sorted(); ++itr){
			if(*itr > newp->value_){
				if(itr == this->begin_sorted()){
					newp->sorted_next_ = sorted_head_;
					newp->sorted_prev_ = NULL;
					sorted_head_->sorted_prev_ = newp;
					sorted_head_ = newp;
					++size_;
					return;
				}
				newp->sorted_next_ = itr.ptr_;
				newp->sorted_prev_ = itr.ptr_->sorted_prev_;
				itr.ptr_->sorted_prev_->sorted_next_ = newp;
				itr.ptr_->sorted_prev_ = newp;
				++size_;
				return;
			} else {
				if(itr.ptr_ == sorted_tail_ && *itr < newp->value_){
					newp->sorted_next_ = NULL;
					newp->sorted_prev_ = sorted_tail_;
					sorted_tail_->sorted_next_ = newp;
					sorted_tail_ = newp;
					++size_;
					return;
				}
			}
		}
	}
}

template <class T>
typename MultiLL<T>::iterator MultiLL<T>::erase(iterator itr){
	assert (size_ > 0);
	--size_;
	iterator result;
	if(itr.type=="chrono"){
		iterator result2(itr.ptr_->chrono_next_, "chrono", this);
		result = result2;
	}
	else if(itr.type=="sorted"){
		iterator result2(itr.ptr_->sorted_next_, "sorted", this);
		result = result2;
	}
	else{
		iterator result2(itr.ptr_->random_next_, "random", this);
		result = result2;
	}
	if(itr.ptr_ == chrono_head_ && chrono_head_ == chrono_tail_){
		chrono_head_ = chrono_tail_ = sorted_head_= sorted_tail_= random_head_= NULL;
	}
	bool chrono_bool = false;
	bool sorted_bool = false;
	if(itr.ptr_ == chrono_head_ || itr.ptr_ == chrono_tail_ ){
		chrono_bool = true;
		if(itr.ptr_ == chrono_head_){
			chrono_head_ = chrono_head_->chrono_next_;
			chrono_head_->chrono_prev_ = NULL;
		} else if(itr.ptr_ == chrono_tail_){
			chrono_tail_ = chrono_tail_->chrono_prev_;
			chrono_tail_->chrono_next_ = NULL;
		}
	}
	if(itr.ptr_ == sorted_head_ || itr.ptr_ == sorted_tail_){
		sorted_bool = true;
		if(itr.ptr_ == sorted_tail_){
			sorted_tail_ = sorted_tail_->sorted_prev_;
			sorted_tail_->sorted_next_ = NULL;
		} else if(itr.ptr_ == sorted_head_){
			sorted_head_ = sorted_head_->sorted_next_;
			sorted_head_->sorted_prev_ = NULL;
		} 
	}
	if(sorted_bool == false){
		itr.ptr_->sorted_prev_->sorted_next_ = itr.ptr_->sorted_next_;
		itr.ptr_->sorted_next_->sorted_prev_ = itr.ptr_->sorted_prev_;
	}
	if(chrono_bool == false){
		itr.ptr_->chrono_prev_->chrono_next_ = itr.ptr_->chrono_next_;
		itr.ptr_->chrono_next_->chrono_prev_ = itr.ptr_->chrono_prev_;
	}
	
	delete itr.ptr_;
	
	return result;
}

template <class T>
void MultiLL<T>::destroy_list() {
	if(size_==0){ return; }
	Node<T>* temp;
	while(true){
		if(chrono_head_->chrono_next_ == NULL){
			delete chrono_head_;
			chrono_head_ = chrono_tail_ = sorted_head_ = sorted_tail_ = random_head_= NULL;
			--size_;
			return;
		}
		temp = chrono_head_->chrono_next_;
		delete chrono_head_;
		chrono_head_ = temp;
		--size_;
	}
}

#endif