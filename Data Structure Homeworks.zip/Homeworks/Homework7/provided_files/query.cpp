#include "query.h"
using namespace std;

Query::Query(){
	matches;
	matches.clear();
	query;
	mismatches;
}

Query::Query(string aQuery, int aMisMatches){
	query = aQuery;
	mismatches = aMisMatches;
	matches;
	matches.clear();
}

string Query::get_query() const{ return query; }
int Query::get_mismatches() const{ return mismatches; }
map<string,vector<int> > Query::get_matches() const{ return matches;}

void Query::add_match(const string& aGene, const int& aLocation, const int& aDiff){
	matches[aGene].push_back(aLocation);
	matches[aGene].push_back(aDiff);
}

void Query::set_mismatches(int aMis_Match){
	mismatches = aMis_Match;
}

void Query::set_name(string name){
	query = name;
}