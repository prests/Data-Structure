#include <string>
#include <map>
#include <vector>
using namespace std;
class Query{
	private:
		string query;
		int mismatches;
		map<string,vector<int> > matches;
	public:
		Query();
		Query(string aQuery, int aMisMatches);
		
		string get_query() const;
		int get_mismatches() const;
		map<string,vector<int> > get_matches() const;
		
		void add_match(const string& aGene, const int& aLocation, const int& aDiff);
		void set_mismatches(int aMis_Match);
		void set_name(string name);
};
