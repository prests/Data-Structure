#include "query.h"
#include <fstream>
#include <iostream>

using namespace std;
//prints out the query and matches
void print_queries(Query& query){
	cout << "Query: " << query.get_query() << endl;
	if(query.get_matches().size()==0){
		cout << "No Match" << endl;
	} else{
		map<string, vector<int> > a_query = query.get_matches();
		map<string,vector<int> >::reverse_iterator itr;
		for(itr = a_query.rbegin(); itr != a_query.rend(); ++itr){
		cout << itr->second[0] << " " << itr->second[1] << " " << itr->first << endl;
		}
	}
}

//finds the seed and then adds characters till its the query length and checks the mismatches before adding
void check_same(map<string,vector<int> >& genomes, Query& query, string& genome_string, int& kmer){
	map<string,vector<int> >::iterator itr = genomes.find(query.get_query().substr(0,kmer));
	if(itr->first == query.get_query().substr(0,kmer)){
		for(int i=0; i<(itr->second.size()); ++i){
			int num_diff = 0;
			for(int j=kmer; j<query.get_query().length(); ++j){
				if(itr->second[i]+j==genome_string.length()){
					num_diff = query.get_mismatches()+1;
					break;
				}
				if(genome_string[(itr->second[i])+j] != query.get_query()[j])
					++num_diff;
			}
			if(num_diff<=query.get_mismatches()){
				query.add_match(genome_string.substr(itr->second[i],query.get_query().length()), itr->second[i], num_diff);
			}
		}
	}
}

//reads file and makes the map or kmers
int main(int argc, char* argv[]){
	map<string,vector<int> > genomes;
	string file_in;
	string genome_file;
	int kmer;
	string genome_string;
	while(true){
		cin >> file_in;
		if(file_in == "quit"){
			break;
		}
		if(file_in == "genome"){
			cin >> genome_file;
			ifstream genome_reader(genome_file.c_str());
			while(genome_reader >> file_in){
				genome_string += file_in;
			}
		}
		if(file_in == "kmer"){
			cin >> kmer;
			string temp_gene;
			for(int i=0; i<genome_string.length(); ++i){
				if(i+kmer-1>=genome_string.length())
					break;
				temp_gene = genome_string.substr(i,kmer);
				genomes[temp_gene];
				genomes[temp_gene].push_back(i);
			}
		}
		if(file_in == "query"){
			int mismatch;
			cin >> mismatch;
			string genome;
			cin >> genome;
			Query a_query(genome,mismatch);
			check_same(genomes, a_query, genome_string, kmer);
			print_queries(a_query);
		}
	}
}