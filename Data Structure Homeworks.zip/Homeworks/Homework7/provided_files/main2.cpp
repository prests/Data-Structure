#include <fstream>
#include <iostream>
#include <string>
#include <map>
#include <vector>
using namespace std;

map<string, vector<int> > check_same(map<string,vector<int> >& genomes, string& genome, int& mismatch, string& genome_string, int& kmer){
	map<string, vector<int> >matches;
	map<string,vector<int> >::iterator itr = genomes.find(genome.substr(0,kmer));
	if(itr->first == genome.substr(0,kmer)){
		for(int i=0; i<(itr->second.size()); ++i){
			int num_diff = 0;
			for(int j=kmer; j<genome.length(); ++j){
				if(itr->second[i]+j==genome.length()){
					num_diff = mismatch+1;
					break;
				}
				if(genome_string[(itr->second[i])+j] != genome[j])
					++num_diff;
			}
			if(num_diff<=mismatch){
				matches[genome_string.substr(itr->second[i],genome.length())].push_back(itr->second[i]);
				matches[genome_string.substr(itr->second[i],genome.length())].push_back(num_diff);
			}
		}
	}
	return matches;
}

int main(int argc, char* argv[]){
	map<string,vector<int> > genomes;
	map<string, vector<int> > matches;
	string file_in="";
	string genome_file="";
	int kmer=0;
	string genome_string="";
	int mismatch=0;
	string genome="";
	while(true){
		cin >> file_in;
		if(file_in == "quit"){
			break;
		}
		if(file_in == "genome"){
			cin >> genome_file;
			ifstream genome_reader(genome_file.c_str());
			while(genome_reader >> file_in){
				genome_string += file_in;
			}
		}
		if(file_in == "kmer"){
			cin >> kmer;
			for(int i=0; i<genome_string.length(); ++i){
				if((i+kmer-1)>=genome_string.length())
					break;
				genomes[genome_string.substr(i,kmer)].push_back(i);
			}
		}
		if(file_in == "query"){
			cin >> mismatch;
			cin >> genome;
			matches = check_same(genomes, genome, mismatch, genome_string, kmer);
			cout << "Query: " << genome << endl;
			if(matches.size()==0){
				cout << "No Match" << endl;
			} else{
				map<string,vector<int> >::reverse_iterator itr;
				for(itr = matches.rbegin(); itr != matches.rend(); ++itr){
					cout << itr->second[0] << " " << itr->second[1] << " " << itr->first << endl;
				}
			}
		}
	}
	return 0;
}