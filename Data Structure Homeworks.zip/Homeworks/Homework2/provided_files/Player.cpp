#include "Player.h"
#include <iostream>
#include <string>

Player::Player(std::string aName){
	name = aName;
	wins = 0;
	loss = 0;
	tie = 0;
	gamewins = 0;
	gameloss = 0;
	percent = 0;
	gamePercent = 0;
	tiePer = 0;
}

std::string Player::getName() const{
	return name;
}

int Player::getWins() const{
	return wins;
}

int Player::getLoss() const{
	return loss;
}

int Player::getTie() const{
	return tie;
}

int Player::getGameWins() const{
	return gamewins;
}

int Player::getGameLoss() const{
	return gameloss;
}

double Player::getPercent() const{
	return percent;
}

double Player::getGamePercent() const{
	return gamePercent;
}

double Player::tiePercent() const{
	return tiePer;
}

void Player::addTie(int aScore){
	tie = tie + aScore;
}

void Player::addWin(){
	++wins;
}

void Player::addLoss(){
	++loss;
}

void Player::addGameWin(int aScore){
	gamewins = gamewins+aScore;
}

void Player::addGameLoss(int aScore){
	gameloss = gameloss+aScore;
}

void Player::getPercentage(){
	percent = ((double) wins)/(wins+loss);
}

void Player::getGamePercentage(){
	gamePercent = ((double) gamewins)/(gamewins+gameloss);
}

void Player::getTiePercentage(){
	tiePer = ((double) tie)/(gamewins+gameloss);
}