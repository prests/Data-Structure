#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <vector>
#include <cstring>
#include "Player.h"
#include <locale>
using namespace std;

//Checks if name is already in players vector
bool checkifin(vector<Player> &people, string name){
	for(int i=0; i<people.size(); ++i){
		if(name == people[i].getName()){
			return true;
		}
	}
	return false;
}
//finds tie in a game
void findties(Player &player, string game){
	int t = 0;
	for(int i=0; i<game.length(); ++i){
		if(game[i] == '-'){
			if(atoi(game.substr(i-1,1).c_str()) == 6 && atoi(game.substr(i+1,1).c_str()) == 7){
				++t;
			} else {
				if(atoi(game.substr(i-1,1).c_str()) == 7 && atoi(game.substr(i+1,1).c_str()) == 8){
					++t;
				}
			}
		}
	}
	player.addTie(t);
}
//Checks first person win loss in game
void getWinsP1(string game, Player &player){
	int w = 0;
	int gameWins = 0;
	int l = 0;
	int gameLoss = 0;
	//Goes through game score substring
	for(int i=0; i<game.length(); ++i){
		if(game[i] == '-'){
			if(atoi(game.substr(i-1,1).c_str())>atoi(game.substr(i+1,1).c_str())){
				++w;
				gameWins = gameWins + atoi(game.substr(i-1,1).c_str());
				gameLoss = gameLoss + atoi(game.substr(i+1,1).c_str());
			} else {
				++l;
				gameWins = gameWins + atoi(game.substr(i-1,1).c_str());
				gameLoss = gameLoss + atoi(game.substr(i+1,1).c_str());
			}
		}
	}
	player.addGameWin(gameWins);
	player.addGameLoss(gameLoss);
	if(w>l){
		player.addWin();
	} else {
		player.addLoss();
	}
}
//check second person win loss in game
void getWinsP2(string game, Player &player){
	int w = 0;
	int gameWins = 0;
	int l = 0;
	int gameLoss = 0;
	//Goes through game score substring
	for(int i=0; i<game.length(); ++i){
		if(game[i] == '-'){
			if(atoi(game.substr(i-1,1).c_str())>atoi(game.substr(i+1,1).c_str())){
				++l;
				gameWins = gameWins + atoi(game.substr(i+1,1).c_str());
				gameLoss = gameLoss + atoi(game.substr(i-1,1).c_str());
			} else {
				++w;
				gameWins = gameWins + atoi(game.substr(i+1,1).c_str());
				gameLoss = gameLoss + atoi(game.substr(i-1,1).c_str());
			}
		}
	}
	player.addGameWin(gameWins);
	player.addGameLoss(gameLoss);
	if(w>l){
		player.addWin();
	} else {
		player.addLoss();
	}
}
//Main organizer
void organize_file(vector<Player> &players, vector<string> &file_info){
	string line;
	//runes through file vector
	for(int i=0; i<file_info.size(); ++i){
		line = file_info[i];
		vector<string> game;
		int pointer = 0;
		bool hit_dig = false;
		//parses line into 3 groups (first person, second person, game scores)
		for(int j=0; j<line.length(); ++j){
			if(line[j] == '.'){
				game.push_back(line.substr(pointer,j-2));
				pointer = j;
			} else {
				if(isdigit(line[j]) && hit_dig == false){
					game.push_back(line.substr(pointer+2,(j-2)-(pointer+2)));
					pointer = j;
					hit_dig = true;
				} else {
					if(j == line.length()-1){
						game.push_back(line.substr(pointer,j-pointer));
					}
				}
			}
		}
		if(checkifin(players, game[0])==false){
			Player temp1(game[0]);
			getWinsP1(game[2],temp1);
			findties(temp1,game[2]);
			players.push_back(temp1);
		} else {
			for(int k=0; k<players.size(); ++k){
				if(players[k].getName() == game[0]){
					getWinsP1(game[2],players[k]);
					findties(players[k],game[2]);
				}
			}
		}
		if(checkifin(players, game[1])==false){
			Player temp2(game[1]);
			getWinsP2(game[2],temp2);
			findties(temp2,game[2]);
			players.push_back(temp2);
		} else {
			for(int k=0; k<players.size(); ++k){
				if(players[k].getName() == game[1]){
					getWinsP2(game[2], players[k]);
					findties(players[k],game[2]);
				}
			}
		}	
	}
}
//gets percentage for matches
void calcpercent(vector<Player> &players){
	for(int i=0; i<players.size(); ++i){
		players[i].getPercentage();
	}
}
//gets percentage for games
void calcgamepercent(vector<Player> &players){
	for(int i=0; i<players.size(); ++i){
		players[i].getGamePercentage();
	}
}
//gets percentage for ties
void calctiepercent(vector<Player> &players){
	for(int i=0; i<players.size(); ++i){
		players[i].getTiePercentage();
	}
}
//sorts matches
bool isBeforePercent(const Player &p1, const Player &p2){
	if(p1.getPercent() > p2.getPercent()){
		return true;
	} else {
		if(p1.getPercent() < p2.getPercent()){
			return false;
		} else {
			int index1 = p1.getName().find(' ');
			int index2 = p2.getName().find(' ');
			if(p1.getName().substr(index1,p1.getName().length()-index1)<p2.getName().substr(index2,p2.getName().length()-index2)){
				return true;
			} else {
				if(p1.getName().substr(index1,p1.getName().length()-index1)>p2.getName().substr(index2,p2.getName().length()-index2)){
					return false;
				} else {
					if(p1.getName().substr(0,index1)<p2.getName().substr(0,index2)){
						return true;
					} else {
						return false;
					}
				}
			}
		}
	}
}
//sorts games
bool isBeforeGamePercent(const Player &p1, const Player &p2){
	if(p1.getGamePercent() > p2.getGamePercent()){
		return true;
	} else {
		if(p1.getGamePercent() < p2.getGamePercent()){
			return false;
		} else {
			int index1 = p1.getName().find(' ');
			int index2 = p2.getName().find(' ');
			if(p1.getName().substr(index1,p1.getName().length()-index1)<p2.getName().substr(index2,p2.getName().length()-index2)){
				return true;
			} else {
				if(p1.getName().substr(index1,p1.getName().length()-index1)>p2.getName().substr(index2,p2.getName().length()-index2)){
					return false;
				} else {
					if(p1.getName().substr(0,index1)<p2.getName().substr(0,index2)){
						return true;
					} else {
						return false;
					}
				}
			}
		}
	}
}
//sorts ties
bool isBeforeTiePercent(const Player &p1, const Player &p2){
	if(p1.tiePercent() > p2.tiePercent()){
		return true;
	} else {
		if(p1.tiePercent() < p2.tiePercent()){
			return false;
		} else {
			int index1 = p1.getName().find(' ');
			int index2 = p2.getName().find(' ');
			if(p1.getName().substr(index1,p1.getName().length()-index1)<p2.getName().substr(index2,p2.getName().length()-index2)){
				return true;
			} else {
				if(p1.getName().substr(index1,p1.getName().length()-index1)>p2.getName().substr(index2,p2.getName().length()-index2)){
					return false;
				} else {
					if(p1.getName().substr(0,index1)<p2.getName().substr(0,index2)){
						return true;
					} else {
						return false;
					}
				}
			}
		}
	}
}
//main sort method for matches
void sortbymatch(vector<Player> &players){
	for(int i=0; i<players.size()-1; ++i){
		for(int j=i+1; j<players.size(); ++j){
			if(isBeforePercent(players[i],players[j])==false){
				Player temp = players[i];
				players[i] = players[j];
				players[j] = temp;
			}
		}
	}
}
//main sort method for games
void sortbygame(vector<Player> &players){
	for(int i=0; i<players.size()-1; ++i){
		for(int j=i+1; j<players.size(); ++j){
			if(isBeforeGamePercent(players[i],players[j])==false){
				Player temp = players[i];
				players[i] = players[j];
				players[j] = temp;
			}
		}
	}
}
//main sort method for ties
void sortbytie(vector<Player> &players){
	for(int i=0; i<players.size()-1; ++i){
		for(int j=i+1; j<players.size(); ++j){
			if(isBeforeTiePercent(players[i],players[j])==false){
				Player temp = players[i];
				players[i] = players[j];
				players[j] = temp;
			}
		}
	}
}
//Main
int main(int argc, char* argv[]) {
	//copys input file to vector
	ifstream myfile(argv[1]);
	string line;
	vector<string> file_info;
	if(myfile.is_open()) {
		while(getline(myfile,line)){
			file_info.push_back(line);
		}
		myfile.close();
	}
	//Organize vector into vector of player classes
	vector<Player> players;
	organize_file(players, file_info);
	//gets percentages
	calctiepercent(players);
	calcpercent(players);
	calcgamepercent(players);
	//out file
	ofstream fin_file(argv[2]);
	if(fin_file.is_open()){
		//matches
		sortbymatch(players);
		fin_file << "MATCH STATISTICS";
		fin_file << "\n";
		fin_file << "Player\t W\t L\t percentage";
		fin_file << "\n";
		for(int i=0; i<players.size(); ++i){
			fin_file << players[i].getName() << "\t" << players[i].getWins() << "\t" << players[i].getLoss() << "\t" << players[i].getPercent();
			fin_file << "\n";
 		}
		fin_file << "\n";
		//games
		sortbygame(players);
		fin_file << "GAME STATISTICS";
		fin_file << "\n";
		fin_file << "Player\t W\t L\t percentage";
		fin_file << "\n";
		for(int i=0; i<players.size(); ++i){
			fin_file << players[i].getName() << "\t" << players[i].getGameWins() << "\t" << players[i].getGameLoss() << "\t" << players[i].getGamePercent();
			fin_file << "\n";
 		}
		fin_file << "\n";
		//ties
		sortbytie(players);
		fin_file << "TIE STATISTICS";
		fin_file << "\n";
		fin_file << "Player\t W\t L\t T\t percentage";
		fin_file << "\n";
		for(int i=0; i<players.size(); ++i){
			fin_file << players[i].getName() << "\t" << players[i].getGameWins() << "\t" << players[i].getGameLoss() << "\t" << players[i].getTie() << "\t" <<players[i].tiePercent();
			fin_file << "\n";
 		}
	}
	fin_file.close();
}