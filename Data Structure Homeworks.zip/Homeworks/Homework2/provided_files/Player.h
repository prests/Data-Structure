#include <string>
class Player {

private:
	std::string name;
	int gamewins;
	int wins;
	int gameloss;
	int loss;
	int tie;
	double percent;
	double gamePercent;
	double tiePer;
	
public:
	//Constructor
	Player(std::string aName);
	//Accessor
	std::string getName() const;
	int getWins() const;
	int getLoss() const;
	int getGameWins() const;
	int getGameLoss() const;
	int getTie() const;
	double tiePercent() const;
	double getPercent() const;
	double getGamePercent() const;
	//Mutator
	void addWin();
	void addLoss();
	void addGameWin(int aScore);
	void addGameLoss(int aScore);
	void addTie(int aScore);
	//Methods
	void getPercentage();
	void getGamePercentage();
	void getTiePercentage();
};