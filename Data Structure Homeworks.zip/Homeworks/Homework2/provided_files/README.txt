HOMEWORK 2: TENNIS CLASSES


NAME:  Shayne Preston


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

< insert collaborators / resources >

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  17 hours



DESCRIPTION OF 3RD STATISTIC:
Please be concise!

Finds the tiebreakers in a game (ie. 6-7 or 7-6) and then divides them by the total number of games played by that player in the tournamnet getting its percentage


RESULTS FROM 3RD STATISTIC:
Paste in a small amount of sample output into this file, or list the
file names of sample input & output included with your submisssion.
Describe what is interesting about your statistic on this data.
Please be concise!

TIE STATISTICS
Player	 W	 L	 T	 percentage
Danai Udomchoke	18	25	1	0.0232558
David Nalbandian	49	44	1	0.0107527
Marcos Baghdatis	73	69	0	0
Ivan Ljubicic	21	25	0	0
Radek Stepanek	24	22	0	0

MISC. COMMENTS TO GRADER:  
Optional, please be concise!

I couldn't figure out how to format the tables but I have the data.


