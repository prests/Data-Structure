// ===================================================================
//
// We provide the Point class and the implementation of several
// QuadTree member functions for printing.  
//
// IMPORTANT: You should modify this file to add all of the necessary
// functionality for the QuadTree class and its helper classes: Node,
// DepthIterator, and BreadthIterator.
//
// ===================================================================

#ifndef quad_tree_h_
#define quad_tree_h_

#include <iostream>
#include <vector>
#include <cassert>
#include <queue>


// ==============================================================
// ==============================================================
// A tiny templated class to store 2D coordinates.  This class works
// with number_type = int, float, double, unsigned char (a 1 byte=8
// bit integer), short (a 2 byte=16 bit integer).

template <class number_type>
class Point {
public:
	Point(const number_type& x_, const number_type& y_) : x(x_),y(y_) {}
	// REPRESENTATION
	number_type x;
	number_type y;
};

// a helper function to print Points to STL output stream
template <class number_type>
inline std::ostream& operator<<(std::ostream &ostr, const Point<number_type> &pt) {
	ostr << "(" << pt.x << "," << pt.y << ")";
	return ostr;
}


template <class number_type, class label_type>
class Node {
	public:
		Node() : pt(NULL), label(NULL), parent(NULL){
			for(int i=0; i<4; ++i)
				children[i]= NULL;
		}
		Node(const Point<number_type>& init, const label_type& lab, Node<number_type,label_type>* par) : pt(init), label(lab), parent(par){
			for(int i=0; i<4; ++i)
				children[i]= NULL;
		}
		Point<number_type> pt;
		label_type label;
		Node<number_type,label_type>* children[4];
		Node<number_type,label_type>* parent;
};

template <class number_type, class label_type> class QuadTree;

template <class number_type, class label_type>
class DepthIterator {
	public:
		DepthIterator() : ptr_(NULL) {}
		DepthIterator(Node<number_type,label_type>* p) : ptr_(p) {}
		DepthIterator(const DepthIterator& old) : ptr_(old.ptr_) {}
		~DepthIterator() {}
		DepthIterator& operator=(const DepthIterator& old) { ptr_ = old.ptr_;  return *this; }
		// operator* gives constant access to the value at the pointer
		const Point<number_type>& operator*() const{ return ptr_->pt; }
		label_type getLabel() const { return ptr_->label; }
		int getDepth() const{ 
			int depth = 0;
			Node<number_type,label_type>* tmp = ptr_;
			while(true){
				//Gets the parent until it reaches the root
				if(tmp->parent==NULL)
					return depth;
				else{
					tmp = tmp->parent;
					depth++; //counter
				}
			}
		}
		// comparions operators are straightforward
		bool operator== (const DepthIterator& rgt) { return ptr_ == rgt.ptr_; }
		bool operator!= (const DepthIterator& rgt) { return ptr_ != rgt.ptr_; }
		// increment & decrement will be discussed in Lecture 19 and Lab 11
		DepthIterator<number_type,label_type>& operator++(){
			//dives left until it can't then goes up and goes right keeping track of nodes that it visited
			if(ptr_->parent==NULL){//for the root puts it in the vector
				depthvec.push_back(ptr_);
				if(ptr_->children[0]!=NULL){
					depthvec.push_back(ptr_->children[0]);
					ptr_=ptr_->children[0];
					return *this;
				}
				if(ptr_->children[1]!=NULL){
					depthvec.push_back(ptr_->children[1]);
					ptr_=ptr_->children[1];
					return *this;
				}
				if(ptr_->children[2]!=NULL){
					depthvec.push_back(ptr_->children[1]);
					ptr_=ptr_->children[1];
					return *this;
				}
				if(ptr_->children[3]!=NULL){
					depthvec.push_back(ptr_->children[1]);
					ptr_=ptr_->children[1];
					return *this;
				}
				ptr_=NULL;
				return *this;
			}
			ptr_ = recursive_plus(ptr_);
		}
		DepthIterator<number_type,label_type> operator++(int){
			DepthIterator<number_type,label_type> tmp(*this);
			++(*this);
			return tmp;
		}
	private:
		// representation
		Node<number_type,label_type>* ptr_;
		std::vector<Node<number_type,label_type>*> depthvec;
		//recursive depth first
		Node<number_type,label_type>* recursive_plus(Node<number_type,label_type>* p){
			depthvec.push_back(p);
			//go to the left most node
			if(p->children[0]!=NULL){
				bool in = false;
				for(int i=0; i<depthvec.size(); ++i){
					if(depthvec[i]==p->children[0]){
						in = true;
						break;
					}
				}
				if(!in){
					p = p->children[0];
					return p;
				}
			}
			if(p->children[1]!=NULL){
				bool in = false;
				for(int i=0; i<depthvec.size(); ++i){
					if(depthvec[i]==p->children[1]){
						in = true;
						break;
					}
				}
				if(!in){
					p = p->children[1];
					return p;
				}
			}
			if(p->children[2]!=NULL){
				bool in = false;
				for(int i=0; i<depthvec.size(); ++i){
					if(depthvec[i]==p->children[2]){
						in = true;
						break;
					}
				}
				if(!in){
					p = p->children[2];
					return p;
				}
			}
			if(p->children[3]!=NULL){
				bool in = false;
				for(int i=0; i<depthvec.size(); ++i){
					if(depthvec[i]==p->children[3]){
						in = true;
						break;
					}
				}
				if(!in){
					p = p->children[3];
					return p;
				}
			}
			//if at the root
			if(p->parent==NULL){
				p = NULL;
				return p;
			}
			//go up
			p = recursive_plus(p->parent);
			return p;
		}
};

template <class number_type, class label_type>
class BreadthIterator {
	public:
		BreadthIterator(): ptr_(NULL) {}
		BreadthIterator(Node<number_type,label_type>* p) : ptr_(p) {}
		BreadthIterator(const BreadthIterator& old) : ptr_(old.ptr_) {}
		~BreadthIterator() {}
		BreadthIterator& operator=(const BreadthIterator& old) { ptr_ = old.ptr_;  return *this; }
		// operator* gives constant access to the value at the pointer
		const Point<number_type>& operator*() const { return ptr_->pt; }
		label_type getLabel() const { return ptr_->label; }
		//same depth
		int getDepth() const{ 
			int depth = 0;
			Node<number_type,label_type>* tmp = ptr_;
			while(true){
				if(tmp->parent==NULL)
					return depth;
				else{
					tmp = tmp->parent;
					depth++;
				}
			}
		}
		// comparions operators are straightforward
		bool operator== (const BreadthIterator& rgt) { return ptr_ == rgt.ptr_; }
		bool operator!= (const BreadthIterator& rgt) { return ptr_ != rgt.ptr_; }
		// increment & decrement will be discussed in Lecture 19 and Lab 11
		//go by level down check the queue for next node
		BreadthIterator<number_type,label_type>& operator++(){
			if(ptr_->parent==NULL){//add root to queue
				if(ptr_->children[0]!=NULL)
					breadthqueue.push(ptr_->children[0]);
				if(ptr_->children[1]!=NULL)
					breadthqueue.push(ptr_->children[1]);
				if(ptr_->children[2]!=NULL)
					breadthqueue.push(ptr_->children[2]);
				if(ptr_->children[3]!=NULL)
					breadthqueue.push(ptr_->children[3]);
				if(breadthqueue.size()!=0){
					ptr_=breadthqueue.front();
					breadthqueue.pop();
				}
				else
					ptr_=NULL;
				return *this;
			}
			//recursive
			ptr_ = recursive_plus(ptr_);
			return *this;
		}
		BreadthIterator<number_type,label_type> operator++(int){
			BreadthIterator<number_type,label_type> tmp(*this);
			++(*this);
			return tmp;
		}
	private:
		// representation
		Node<number_type,label_type>* ptr_;
		std::queue<Node<number_type,label_type>*>breadthqueue;
		
		Node<number_type,label_type>* recursive_plus(Node<number_type,label_type>* p){
			if(breadthqueue.size()==0){//if queue is empty then at end
				p = NULL;
				return p;
			}//pushes all the children on
			if(p->children[0]!=NULL)
				breadthqueue.push(ptr_->children[0]);
			if(p->children[1]!=NULL)
				breadthqueue.push(ptr_->children[1]);
			if(p->children[2]!=NULL)
				breadthqueue.push(ptr_->children[2]);
			if(p->children[3]!=NULL)
				breadthqueue.push(ptr_->children[3]);
			p = breadthqueue.front();
			breadthqueue.pop();
			return p;
		}
};	

template <class number_type, class label_type>
class QuadTree {
	public:
		//constructor, assignment, destructor
		QuadTree() : root_(NULL), size_(0){}
		QuadTree(const QuadTree<number_type, label_type>& old) : size_(old.size_){ 
			root_ = this->copy_tree(old.root_); }
		~QuadTree() { this->destroy_tree(root_);  root_ = NULL; }
		QuadTree& operator=(const QuadTree<number_type, label_type>& old) {
			if (&old != this) {
				this->destroy_tree(root_);
				root_ = this->copy_tree(old.root_);
				size_ = old.size_;
			}
			return *this;
		}
	
		typedef DepthIterator<number_type,label_type> iterator;
		typedef BreadthIterator<number_type,label_type> bf_iterator;

		int size() const { return size_; }
		int height(){ return height(root_); }
		bool operator==(const QuadTree<number_type,label_type>& old) const { return (old.root_ == this->root_); }

		// FIND, INSERT & ERASE
		iterator find(const number_type& x, const number_type& y) { return find(x, y, root_); }
		std::pair< iterator, bool > insert(Point<number_type> const& key_value, label_type const& key_label) { return insert(key_value, key_label,root_, NULL); }

		// ITERATORS
		iterator begin() const { 
			if (!root_) return iterator(NULL);
			Node<number_type,label_type>* p = root_;
			return iterator(p);
		}
		
		bf_iterator bf_begin() const {
			if (!root_) return bf_iterator(NULL);
			Node<number_type,label_type>* p = root_;
			return bf_iterator(p);
		}
		
		iterator end() const { return iterator(NULL); }
		bf_iterator bf_end() const{ return bf_iterator(NULL); }
		
		// plot driver function
		// takes in the maximum x and y coordinates for these data points
		// the optional argument draw_lines defaults to true
		void plot(int max_x, int max_y, bool draw_lines=true) const {
			// allocate blank space for the center of the board
			std::vector<std::string> board(max_y+1,std::string(max_x+1,' '));
			// edit the board to add the point labels and draw vertical and
			// horizontal subdivisions
			plot(root_,board,0,max_x,0,max_y,draw_lines);
			// print the top border of the plot
			std::cout << "+" << std::string(max_x+1,'-') << "+" << std::endl;
			for (int i = 0; i <= max_y; i++) {
				// print each row of the board between vertical border bars
				std::cout << "|" << board[i] << "|" << std::endl;
			}
			// print the top border of the plot
			std::cout << "+" << std::string(max_x+1,'-') << "+" << std::endl;
		}
		
		// prints all of the tree data with a pre-order (node first, then
		// children) traversal of the tree structure

		// driver function
		void print_sideways() const { print_sideways(root_,""); }
		
	private:
		Node<number_type,label_type>* root_;
		int size_;
		int ch1;
		int ch2;
		int ch3;
		int ch4;
		//recursively take the children at each node put them in a new node
		Node<number_type,label_type>* copy_tree(Node<number_type,label_type>* old_root) {
			Node<number_type,label_type>* new_root= new Node<number_type,label_type>(old_root->pt, old_root->label, NULL);
			if(old_root->children[0] == NULL){
				new_root->children[0] = NULL;
			}
			else{
				new_root->children[0] = copy_tree(old_root->children[0]);
				new_root->children[0]->parent = new_root;
			}
			if(old_root->children[1] == NULL){			
				new_root->children[1] = NULL;
			}
			else{
				new_root->children[1] = copy_tree(old_root->children[1]);
				new_root->children[1]->parent = new_root;
			}
			if(old_root->children[2] == NULL){
				new_root->children[2] = NULL;
			}
			else{
				new_root->children[2] = copy_tree(old_root->children[2]);
				new_root->children[2]->parent = new_root;
			}
			if(old_root->children[3] == NULL){
				new_root->children[3] = NULL;
			}
			else{
				new_root->children[3] = copy_tree(old_root->children[3]);
				new_root->children[3]->parent = new_root;
			}
			return new_root;
		}
		
		void destroy_tree(Node<number_type,label_type>* p){
			if(p != NULL){// recursively deletes the node at each children node
				destroy_tree(p->children[0]);
				destroy_tree(p->children[1]);
				destroy_tree(p->children[2]);
				destroy_tree(p->children[3]);
				
				delete p;
				p = NULL;
				size_ = 0;
			}
		}

		iterator find(const number_type& x, const number_type& y, Node<number_type,label_type>* p) {
			Node<number_type,label_type>* tmp = p;
			while(true){//seaches based by point value to which children node it has to go to until found or NULL
				if(!tmp){//NULL
					return iterator(NULL);
				}
				if(tmp->pt.x>x){
					if(tmp->pt.y>y)
						tmp = tmp->children[0];
					else if(tmp->pt.y<y)
						tmp = tmp->children[2];
				} else{
					if(tmp->pt.x<x){
						if(tmp->pt.y>y)
							tmp = tmp->children[1];
						else if(tmp->pt.y<y)
							tmp = tmp->children[3];
					} else
						return iterator(tmp);
				}
			} 
		}
		
		std::pair<iterator,bool> insert(const Point<number_type>& key_point, const label_type& key_label, Node<number_type,label_type>*& p, Node<number_type,label_type>* old){
			if(!p){//NULL
				p = new Node<number_type,label_type>(key_point,key_label,old);
				this->size_++;
				return std::pair<iterator,bool>(iterator(p), true);
			}
			else {//go to NULL or point based by point value recursively adds new node
				if(key_point.x<p->pt.x){
					if(key_point.y<p->pt.y)
						return insert(key_point, key_label, p->children[0], p);
					if(key_point.y>p->pt.y)
						return insert(key_point, key_label, p->children[2], p);
				}
				if(key_point.x>p->pt.x){
					if(key_point.y<p->pt.y)
						return insert(key_point, key_label, p->children[1], p);
					if(key_point.y>p->pt.y)
						return insert(key_point, key_label, p->children[3], p);
				}
				else
					return std::pair<iterator,bool>(iterator(p), false);
			}
		}
		
		int height(Node<number_type,label_type>* p){
			if(!p) return -1;
			if(p->children[0] == NULL && p->children[1] == NULL && p->children[2] == NULL && p->children[3] == NULL)
				return 0;
			else{//recursively calculates the sum of the children 
				ch1 = height(p->children[0]);
				ch2 = height(p->children[1]);
				ch3 = height(p->children[2]);
				ch4 = height(p->children[3]);
				int max = 0;
				std::vector<int> tmp;
				tmp.push_back(ch1);
				tmp.push_back(ch2);
				tmp.push_back(ch3);
				tmp.push_back(ch4);	
				for(int i=0; i<4; ++i){//finds max
					if(tmp[i]>max)
						max = tmp[i];
				}
				max++;
				return max;
			}
		}
// ==============================================================
// PROVIDED CODE : QUAD TREE MEMBER FUNCTIONS FOR PRINTING
// ==============================================================

// NOTE: this function only works for quad trees with non negative
// integer coordinates and char labels

// NOTE2: this function assumes that no two points have the same x
// coordinate or the same y coordinate.



	
	// actual recursive function for plotting
	void plot(Node<number_type,label_type> *p, std::vector<std::string> &board,
		int x_min, int x_max, int y_min, int y_max, bool draw_lines) const {
		// base case, draw nothing if this node is NULL
		if (p == NULL) return;
		// check that the dimensions range of this node make sense
		assert (x_min >= 0 && x_min <= x_max);
		assert (y_min >= 0 && y_min <= y_max);
		assert (board.size() >= y_max);
		assert (board[0].size() >= x_max);
		// verify that the point stored at this node fits on the board
		assert (p->pt.y >= 0 && p->pt.y < board.size());
		assert (p->pt.x >= 0 && p->pt.x < board[0].size());
		// draw the vertical and horizontal bars extending across the
		// range of this node
		if (draw_lines) {
			for (int x = x_min; x <= x_max; x++) {
				board[p->pt.y][x] = '-';
			}
			for (int y = y_min; y <= y_max; y++) {
				board[y][p->pt.x] = '|';
			}
		}
		// draw this label
		board[p->pt.y][p->pt.x] = p->label;
		// recurse on the 4 children
		plot(p->children[0],board,x_min ,p->pt.x-1,y_min ,p->pt.y-1,draw_lines);
		plot(p->children[1],board,p->pt.x+1,x_max ,y_min ,p->pt.y-1,draw_lines);
		plot(p->children[2],board,x_min ,p->pt.x-1,p->pt.y+1,y_max ,draw_lines);
		plot(p->children[3],board,p->pt.x+1,x_max ,p->pt.y+1,y_max ,draw_lines);
	}


// ==============================================================


	// actual recursive function
	void print_sideways(Node<number_type,label_type>* p, const std::string &indent) const {
	  // base case
	  if (p == NULL) return;
	  // print out this node
	  std::cout << indent << p->label << " (" << p->pt.x << "," << p->pt.y << ")" << std::endl;
	  // recurse on each of the children trees
	  // increasing the indentation
	  print_sideways(p->children[0],indent+"  ");
	  print_sideways(p->children[1],indent+"  ");
	  print_sideways(p->children[2],indent+"  ");
	  print_sideways(p->children[3],indent+"  ");
	}

// ==============================================================
// ==============================================================

};

#endif
