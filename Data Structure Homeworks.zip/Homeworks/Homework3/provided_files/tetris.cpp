#include "tetris.h"
#include <iostream>

char* copy_data(char* data_old, char* data_new, int len){
	for(int i=0; i<len; ++i){
		data_new[i] = data_old[i];
	}
	std::cout << "data" << data_new[0] << std::endl;
	delete [] data_old;
	std::cout << "deletes" << std::endl;
	return data_new;
}
Tetris::Tetris(int aWidth){
	width = aWidth;
	heights = new int[width];
	for(int i=0; i<width; ++i){
		heights[i] = 0;
	}
	data = new char*[width];
	squares = 0;
}

int Tetris::get_width() const{
	return width;
}

int* Tetris::getHeight() const{
	return heights;
}

char** Tetris::getdata() const{
	return data;
}

void Tetris::changeWidth(int aWidth){
	width = aWidth;
}

void Tetris::add_piece(char letter, int rotation, int row){
	if(letter == 'I') {
		if(rotation == 90 || rotation == 270){
			std::cout << "in 90" << std::endl;
			if(row+3>=width){
				std::cout<<"doesn't add"<<std::endl;
				return;
			}
			int size = find_highest(row, 4);
			std::cout << size << std::endl;
			int temp1 = heights[row];
			int temp2 = heights[row+1];
			int temp3 = heights[row+2];
			int temp4 = heights[row+3];
			heights[row] = heights[row] + (size-heights[row])+1;
			heights[row+1] = heights[row+1] + (size-heights[row+1])+1;
			heights[row+2] = heights[row+2] + (size-heights[row+2])+1;
			heights[row+3] = heights[row+3] + (size-heights[row+3])+1;
			std::cout << "new heights" << std::endl;
			char* r1 = new char[heights[row]];
			std::cout << "made one" << std::endl;
			char* r2 = new char[heights[row+1]];
			std::cout << "made 2" << std::endl;
			char* r3 = new char[heights[row+2]];
			std::cout << "made 3" << std::endl;
			std::cout << heights[row+3] <<std::endl;
			char* r4 = new char[heights[row+3]];
			std::cout << "i b4 copy" << std::endl;
			r1 = copy_data(data[row], r1, temp1);
			std::cout << "i after copy" << std::endl;
			r2 = copy_data(data[row+1], r2, temp2);
			r3 = copy_data(data[row+2], r3, temp3);
			r4 = copy_data(data[row+3], r4, temp4);
			for(int i=0; i<1; ++i){
				r1[heights[row]-(1-i)] = 'I';
				r2[heights[row+1]-(1-i)] = 'I';
				r3[heights[row+2]-(1-i)] = 'I';
				r4[heights[row+3]-(1-i)] = 'I';
			}
			data[row] = r1;
			data[row+1] = r2;
			data[row+2] = r3;
			data[row+3] = r4;
		} else {
			if(rotation == 0 || rotation == 180){
				if(row>width){
					return;
				}
				int temp1 = heights[row];
				heights[row] = heights[row] +4;
				char* rect = new char[heights[row]];
				rect = copy_data(data[row], rect, temp1);
				for(int i=0; i<4; ++i){
					rect[heights[row]-(4-i)] = 'I';
				}
				data[row] = rect;
			}
		}
	} else{
		if(letter == 'O'){
			if(row+2>width){
				std::cout << "in return" << std::endl;
				return;
			}
			std::cout << "in O" << std::endl;
			int size = find_highest(row, 2);
			std::cout << size << std::endl;
			int temp1 = heights[row];
			int temp2 = heights[row+1];
			heights[row] = heights[row]+(size-heights[row])+2;
			heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
			char* left = new char[heights[row]];
			char* right = new char[heights[row+1]];
			std::cout << "before copy data" << std::endl;
			left = copy_data(data[row], left, temp1);
			std::cout << "after left" << std::endl;
			right = copy_data(data[row+1], right, temp2);
			std::cout << "Before for loop" << std::endl;
			for(int i=0; i<2; ++i){
				left[heights[row]-(2-i)] = 'O';
				right[heights[row+1]-(2-i)] = 'O';
			}
			data[row] = left;
			data[row+1]= right;
		} else {
			if(letter == 'T'){
				if(rotation == 90 ){
					if(row+1>width){
						return;
					}
					int size = find_highest(row, 2);
					int temp1 = heights[row];
					int temp2 = heights[row+1];
					if(heights[row] > heights[row+1]){
						heights[row] = heights[row]+(size-heights[row])+1;
						heights[row+1] = heights[row]+(size-heights[row]+2);
					} else {
						heights[row] = heights[row]+(size-heights[row])+2;
						heights[row+1] = heights[row+1]+(size-heights[row+1])+3;
					}
					char* t1 = new char[heights[row]];
					char* t2 = new char[heights[row+1]];
					t1 = copy_data(data[row], t1, temp1);
					t2 = copy_data(data[row+1], t2, temp2);
					t1[heights[row]-1] = 'T';
					for(int i=0; i<3; ++i){
						t2[heights[row+1]-(3-i)] = 'T';
					}
					data[row] = t1;
					data[row+1] = t2;
				} else {
					if(rotation == 180){
						if(row+2>width){
							return;
						}
						int size = find_highest(row, 3);
						int temp1 = heights[row];
						int temp2 = heights[row+1];
						int temp3 = heights[row+2];
						heights[row] = heights[row]+(size-heights[row])+1;
						heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
						heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
						char* t1 = new char[heights[row]];
						char* t2 = new char[heights[row+1]];
						char* t3 = new char[heights[row+2]];
						t1 = copy_data(data[row], t1, temp1);
						t2 = copy_data(data[row+1], t2, temp2);
						t3 = copy_data(data[row+2], t3, temp3);
						t1[heights[row]-1] = 'T';
						t2[heights[row+1]-2] = 'T';
						t2[heights[row+2]-1] = 'T';
						t3[heights[row+3]-1] = 'T';
						data[row] = t1;
						data[row+1] = t2;
						data[row+2] = t3;
					} else {
						if(rotation == 270){
							if(row+1>width){
								return;
							}
							int size = find_highest(row, 2);
							int temp1 = heights[row];
							int temp2 = heights[row+1];
							if(heights[row+1] > heights[row]){
								heights[row] = heights[row]+(size-heights[row])+2;
								heights[row+1] = heights[row]+(size-heights[row]+1);
							} else {
								heights[row] = heights[row]+(size-heights[row])+3;
								heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
							}
							char* t1 = new char[heights[row]];
							char* t2 = new char[heights[row+1]];
							t1 = copy_data(data[row], t1, temp1);
							t2 = copy_data(data[row+1], t2, temp2);
							t2[heights[row]-1] = 'T';
							for(int i=0; i<3; ++i){
								t1[heights[row]-(3-i)] = 'T';
							}
							data[row] = t1;
							data[row+1] = t2;
						} else {
							if(rotation == 0){
								if(row+2>width){
									return;
								}
								int size = find_highest(row, 3);
								int temp1 = heights[row];
								int temp2 = heights[row+1];
								int temp3 = heights[row+2];
								if(heights[row]>heights[row+1] || heights[row+2]>heights[row+1]){
									heights[row] = heights[row]+(size-heights[row])+1;
									heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
									heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
								} else {
									heights[row] = heights[row]+(size-heights[row])+2;
									heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
									heights[row+2] = heights[row+2]+(size-heights[row+2])+2;
								}
								char* t1 = new char[heights[row]];
								char* t2 = new char[heights[row+1]];
								char* t3 = new char[heights[row+2]];
								t1 = copy_data(data[row], t1, temp1);
								t2 = copy_data(data[row+1], t2, temp2);
								t3 = copy_data(data[row+2], t3, temp3);
								t1[heights[row]-1] = 'T';
								t2[heights[row+1]-2] = 'T';
								t2[heights[row+1]-1] = 'T';
								t3[heights[row+2]-1] = 'T';
								data[row] = t1;
								data[row+1] = t2;
								data[row+2] = t3;
							}
						} 
					}
				}
			} else {
				if(letter == 'Z'){
					if(rotation == 90 || rotation == 270){
						if(row+1>width){
							return;
						}
						int size = find_highest(row, 2);
						int temp1 = heights[row];
						int temp2 = heights[row+1];
						if(heights[row+1]>heights[row]){
							heights[row] = heights[row]+(size-heights[row])+1;
							heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
						} else {
							heights[row] = heights[row]+(size-heights[row])+2;
							heights[row+1] = heights[row+1]+(size-heights[row+1])+3;
						}
						char* z1 = new char[heights[row]];
						char* z2 = new char[heights[row+1]];
						z1 = copy_data(data[row], z1, temp1);
						z2 = copy_data(data[row+1], z2, temp2);
						z1[heights[row]-2] = 'Z';
						z1[heights[row+1]-1] = 'Z';
						z2[heights[row+2]-2] = 'Z';
						z2[heights[row+2]-1] = 'Z';
						data[row] = z1;
						data[row+1] = z2;
					} else {
						if(rotation == 0 || rotation == 180){
							if(row+2>width){
								return;
							}
							int size = find_highest(row, 3);
							int temp1 = heights[row];
							int temp2 = heights[row+1];
							int temp3 = heights[row+2];
							if(heights[row] > heights[row+1] && heights[row]> heights[row+2]){
								heights[row] = heights[row]+(size-heights[row])+1;
								heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
								heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
							} else {
								heights[row] = heights[row]+(size-heights[row])+2;
								heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
								heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
							}
							char* z1 = new char[heights[row]];
							char* z2 = new char[heights[row+1]];
							char* z3 = new char[heights[row+2]];
							z1 = copy_data(data[row], z1, temp1);
							z2 = copy_data(data[row+1], z2, temp2);
							z3 = copy_data(data[row+2], z3, temp3);
							z1[heights[row]-1] = 'Z';
							z2[heights[row+1]-2] = 'Z';
							z2[heights[row+1]-2] = 'Z';
							z3[heights[row+2]-1] = 'Z';
							data[row] = z1;
							data[row+1] = z2;
							data[row+2] = z3;
						}
					}
				} else {
					if(letter == 'S'){
						if(rotation == 90 || rotation == 270){
							if(row+1>width){
								return;
							}
							int temp1 = heights[row];
							int temp2 = heights[row+1];
							int size = find_highest(row, 2);
							if(heights[row]>heights[row+1]){
								heights[row] = heights[row]+(size-heights[row])+2;
								heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
							} else {
								heights[row] = heights[row]+(size-heights[row])+3;
								heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
							}
							char* s1 = new char[heights[row]];
							char* s2 = new char[heights[row+1]];
							s1 = copy_data(data[row], s1, temp1);
							s2 = copy_data(data[row+1], s2, temp2);
							s1[heights[row]-2] = 'S';
							s1[heights[row]-1] = 'S';
							s2[heights[row+1]-2] = 'S';
							s2[heights[row+1]-1] = 'S';
							data[row] = s1;
							data[row+1] = s2;
						} else {
							if(rotation == 0 || rotation == 180){
								if(row+2>width){
									return;
								}
								int size = find_highest(row, 3);
								int temp1 = heights[row];
								int temp2 = heights[row+1];
								int temp3 = heights[row+2];
								if(heights[row+2]> heights[row] && heights[row+2]>heights[row+1]){
									heights[row] = heights[row]+(size-heights[row])+1;
									heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
									heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
								} else{
									heights[row] = heights[row]+(size-heights[row])+1;
									heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
									heights[row+2] = heights[row+2]+(size-heights[row+2])+2;
								}
								char* s1 = new char[heights[row]];
								char* s2 = new char[heights[row+1]];
								char* s3 = new char[heights[row+2]];
								s1 = copy_data(data[row], s1, temp1);
								s2 = copy_data(data[row+1], s2, temp2);
								s3 = copy_data(data[row+2], s3, temp3);
								s1[heights[row]-1] = 'S';
								s2[heights[row+1]-2] = 'S';
								s2[heights[row+1]-1] = 'S';
								s3[heights[row+2]-1] = 'S';
								data[row] = s1;
								data[row+1] = s2;
								data[row+2] = s3;
							}
						}
					} else {
						if(letter == 'L'){
							if(rotation == 90){
								if(row+2>width){
									return;
								}
								int size = find_highest(row, 3);
								int temp1 = heights[row];
								int temp2 = heights[row+1];
								int temp3 = heights[row+2];
								if(heights[row+1]>heights[row] || heights[row+2]>heights[row]){
									heights[row] = heights[row]+(size-heights[row])+1;
									heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
									heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
								} else {
									heights[row] = heights[row]+(size-heights[row])+2;
									heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
									heights[row+2] = heights[row+2]+(size-heights[row+2])+2;
								}
								char* l1 = new char[heights[row]];
								char* l2 = new char[heights[row+1]];
								char* l3 = new char[heights[row+2]];
								l1 = copy_data(data[row], l1, temp1);
								l2 = copy_data(data[row+1], l2, temp2);
								l3 = copy_data(data[row+2], l3, temp3);
								l1[heights[row]-2] = 'L';
								l1[heights[row]-1] = 'L';
								l2[heights[row+1]-1] = 'L';
								l3[heights[row+2]-1] = 'L';
								data[row] = l1;
								data[row+1] = l2;
								data[row+2] = l3;
							} else {
								if(rotation == 180){
									if(row+1>width){
										return;
									}
									int size = find_highest(row, 2);
									int temp1 = heights[row];
									int temp2 = heights[row+1];
									if(heights[row]-heights[row+1]>=2){
										heights[row] = heights[row]+(size-heights[row])+1;
										heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
									} else{
										if(heights[row]-heights[row+1]==1){
											heights[row] = heights[row]+(size-heights[row])+2;
											heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
										} else{
											heights[row] = heights[row]+(size-heights[row])+3;
											heights[row+1] = heights[row+1]+(size-heights[row+1])+3;
										}
									}
									char* l1 = new char[heights[row]];
									char* l2 = new char[heights[row+1]];
									l1 = copy_data(data[row], l1, temp1);
									l2 = copy_data(data[row+1], l2, temp2);
									l1[heights[row]-1] = 'L';
									for(int i=0; i<3; ++i){
										l2[heights[row+1]-(3-i)] = 'L';
									}
									data[row] = l1;
									data[row+1] = l2;
								} else {
									if(rotation == 270){
										if(row+2>width){
											return;
										}
										int size = find_highest(row, 3);
										int temp1 = heights[row];
										int temp2 = heights[row+1];
										int temp3 = heights[row+2];
										heights[row] = heights[row]+(size-heights[row])+1;
										heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
										heights[row+2] = heights[row+2]+(size-heights[row+2])+2;
										char* l1 = new char[heights[row]];
										char* l2 = new char[heights[row+1]];
										char* l3 = new char[heights[row+2]];
										l1 = copy_data(data[row], l1, temp1);
										l2 = copy_data(data[row+1], l2, temp2);
										l3 = copy_data(data[row+2], l3, temp3);
										l1[heights[row]-1] = 'L';
										l2[heights[row+1]-1] = 'L';
										l3[heights[row+2]-2] = 'L';
										l3[heights[row+2]-1] = 'L';
										data[row] = l1;
										data[row+1] = l2;
										data[row+2] = l3;
									} else {
										if(rotation == 0){
											if(row+1>width){
												return;
											}
											int size = find_highest(row, 2);
											int temp1 = heights[row];
											int temp2 = heights[row+1];
											heights[row] = heights[row]+(size-heights[row])+3;
											heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
											char* l1 = new char[heights[row]];
											char* l2 = new char[heights[row+1]];
											l1 = copy_data(data[row], l1, temp1);
											l2 = copy_data(data[row+1], l2, temp2);
											l2[heights[row+1]-1] = 'L';
											for(int i=0; i<3; ++i){
												l1[heights[row]-(3-i)] = 'L';
											}
											data[row] = l1;
											data[row+1] = l2;
										}
									}
								}
							}
						} else {
							if(letter == 'J'){
								if(rotation == 90){
									if(row+2>width){
										return;
									}
									int size = find_highest(row, 3);
									int temp1 = heights[row];
									int temp2 = heights[row+1];
									int temp3 = heights[row+2];
									heights[row] = heights[row]+(size-heights[row])+2;
									heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
									heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
									char* j1 = new char[heights[row]];
									char* j2 = new char[heights[row+1]];
									char* j3 = new char[heights[row+2]];
									j1 = copy_data(data[row], j1, temp1);
									j2 = copy_data(data[row+1], j2, temp2);
									j3 = copy_data(data[row+2], j3, temp3);
									j1[heights[row]-2] = 'J';
									j1[heights[row]-1] = 'J';
									j2[heights[row+1]-1] = 'J';
									j3[heights[row+2]-1] = 'J';
									data[row] = j1;
									data[row+1] = j2;
									data[row+2] = j3;
								} else {
									if(rotation == 180){
										if(row+1>width){
											return;
										}
										int size = find_highest(row, 2);
										int temp1 = heights[row];
										int temp2 = heights[row+1];
										if(heights[row+1]-heights[row]>=2){
											heights[row] = heights[row]+(size-heights[row])+1;
											heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
										} else{
											if(heights[row+1]-heights[row]==1){
												heights[row] = heights[row]+(size-heights[row])+2;
												heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
											} else {
												heights[row] = heights[row]+(size-heights[row])+3;
												heights[row+1] = heights[row+1]+(size-heights[row+1])+3;
											}
										}
										char* j1 = new char[heights[row]];
										char* j2 = new char[heights[row+1]];
										j1 = copy_data(data[row], j1, temp1);
										j2 = copy_data(data[row+1], j2, temp2);
										j2[heights[row+1]-1] = 'J';
										for(int i=0; i<3; ++i){
											j1[heights[row]-(3-i)] = 'J';
										}
										data[row] = j1;
										data[row+1] = j2;
									} else {
										if(rotation == 270){
											if(row+2>width){
												return;
											}
											int size = find_highest(row, 3);
											int temp1 = heights[row];
											int temp2 = heights[row+1];
											int temp3 = heights[row+2];
											if(heights[row]>heights[row+2] || heights[row+1]>heights[row+2]){
												heights[row] = heights[row]+(size-heights[row])+1;
												heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
												heights[row+2] = heights[row+2]+(size-heights[row+2])+1;
											} else {
												heights[row] = heights[row]+(size-heights[row])+2;
												heights[row+1] = heights[row+1]+(size-heights[row+1])+2;
												heights[row+2] = heights[row+2]+(size-heights[row+2])+2;
											}
											char* j1 = new char[heights[row]];
											char* j2 = new char[heights[row+1]];
											char* j3 = new char[heights[row+2]];
											j1 = copy_data(data[row], j1, temp1);
											j2 = copy_data(data[row+1], j2, temp2);
											j3 = copy_data(data[row+2], j3, temp3);
											j1[heights[row]-1] = 'J';
											j2[heights[row+1]-1] = 'J';
											j3[heights[row+2]-2] = 'J';
											j3[heights[row+2]-1] = 'J';
											data[row] = j1;
											data[row+1] = j2;
											data[row+2] = j3;
										} else {
											if(rotation == 0){
												if(row+1>width){
													return;
												}
												int size = find_highest(row, 2);
												int temp1 = heights[row];
												int temp2 = heights[row+1];
												heights[row] = heights[row]+(size-heights[row])+1;
												heights[row+1] = heights[row+1]+(size-heights[row+1])+1;
												char* j1 = new char[heights[row]];
												char* j2 = new char[heights[row+1]];
												j1 = copy_data(data[row], j1, temp1);
												j2 = copy_data(data[row+1], j2, temp2);
												j1[heights[row]-1] = 'J';
												for(int i=0; i<3; ++i){
													j2[heights[row+1]-(3-i)] = 'J';
												}
												data[row] = j1;
												data[row+1] = j2;
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	}
	squares = squares+4;
}
void Tetris::remove_line(int line){
	for(int i=0; i<width; ++i){
		char* temp = new char[heights[i]-1];
		int k = 0;
		for(int j=0; j<heights[i]; ++j){
			if(j != line){
				temp[k] = data[i][j];
				++k;
			}
		}
		heights[i] = heights[i]-1;
		delete data[i];
		data[i] = temp;
	}
	squares = squares - width;
}

void Tetris::remove_full_row(){
	int size = find_highest(0,width);
	for(int i=0; i<size; ++i){
		int count = 0;
		for(int j=0; j<width; ++j){
			if(data[j][i] != '\0'){
				++count;
			}
		}
		if(count == width){
			remove_line(i);
			return;
		}
	}
}
/*
void Tetris::print(){
	for(int i=0; i<width; ++i){
		std::cout << heights[i] << "| ";
		for(int j=0; j<heights[i]; ++j){
			if(data[i][j]=='\0'){
				std::cout << " ";
			} else{
				std::cout << data[i][j];
			}
		}
		std::cout << "" << std::endl;
	}
}
*/
int Tetris::find_highest(int loc, int len){
	int size = heights[loc];
	for(int i=loc; i<loc+len; ++i){
		if(size < heights[i]){
			size = heights[i];
		}
	}
	return size;
	
}

int Tetris::get_max_height() const{
	int size = heights[0];
	for(int i=0; i<width; ++i){
		if(size < heights[i]){
			size = heights[i];
		}
	}
	return size;
}

int Tetris::count_squares(){
	return squares;
}

void Tetris::destroy(){
	delete [] heights;
	for(int i=0; i<width; ++i){
		delete [] data[i];
	}
	delete [] data;
}