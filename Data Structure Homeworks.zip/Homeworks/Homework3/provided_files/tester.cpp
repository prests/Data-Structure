#include "tetris.h"

int main(){
	Tetris tetris(6);
	tetris.add_piece('O',0,0);
	tetris.add_piece('O',0,2);
	tetris.add_piece('O',0,4);
	tetris.print();
	tetris.check_row();
	tetris.print();
}