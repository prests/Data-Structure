HOMEWORK 3: DYNAMIC TETRIS ARRAYS


NAME:  Shayne Preston


COLLABORATORS AND OTHER RESOURCES:
List the names of everyone you talked to about this assignment
(classmates, TAs, ALAC tutors, upperclassmen, students/instructor via
LMS, etc.), and all of the resources (books, online reference
material, etc.) you consulted in completing this assignment.

TAs and ALAC sessions

Remember: Your implementation for this assignment must be done on your
own, as described in "Academic Integrity for Homework" handout.



ESTIMATE OF # OF HOURS SPENT ON THIS ASSIGNMENT:  20



MISC. COMMENTS TO GRADER:  
Optional, please be concise!

I thought I had a grasph on the assignment at hand but I recieved an error when deleting old arrays that even after sitting through hours of TA session and an ALAC session I was still unable
to figure it out. The code stops without producing an error when deleting the old array but if i delete the new array it works periodically. this preventing from performing tests in the main.cpp
file but after doing tests on my own the outputs were fine. I have no idea the solution for this.
