class Tetris{
	
private:
	int width;
	int* heights;
	char** data;
	int squares;
public:
	//Constructor
	Tetris(int aWidth);
	//Accessor
	int get_width() const;
	int* getHeight() const;
	char** getdata() const;
	void remove_full_row();
	int count_squares();
	//Mutator
	void changeHeight(int aHeight);
	void changeWidth(int aWidth);
	//Methods
	void add_piece(char letter, int rotation, int row);
	int find_highest(int loc, int len);
	void print() const;
	void remove_line(int line);
	int get_max_height() const;
	void destroy();
};