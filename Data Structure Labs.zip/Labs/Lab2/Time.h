class Time {

public:
	Time();
	Time(int aHour, int aMinute, int aSecond);
	
	// ACCESSORS
	int getHour() const;
	int getMinute() const;
	int getSecond() const;
	// MUTATORS
	void setHour(int newHour);
	void setMinute(int newMinute);
	void setSecond(int newSecond);
	// METHODS
	void printAmPm();
	
private:
	int hour;
	int minute;
	int second;
		
};

bool IsEarlierThan(const Time& t1, const Time& t2);