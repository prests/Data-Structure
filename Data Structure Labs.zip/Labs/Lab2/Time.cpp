#include "Time.h"
#include <iostream>
#include <vector>
#include <algorithm>

Time::Time(int aHour, int aMinute, int aSecond) {
	hour = aHour;
	minute = aMinute;
	second = aSecond;
}

Time::Time() {
	hour = 0;
	minute = 0;
	second = 0;
}

int Time::getHour() const {
	return hour;
}

int Time::getMinute() const {
	return minute;
}

int Time::getSecond() const {
	return second;
}

void Time::setHour(int newHour) {
	hour = newHour;
}

void Time::setMinute(int newMinute) {
	minute = newMinute;
}

void Time::setSecond(int newSecond) {
	second = newSecond;
}

void Time::printAmPm() {
	if(hour >= 12){
		std::cout << hour%12 << ":" << minute << ":" << second << " pm" << std::endl;
	} else {
		std::cout << hour << ":" << minute << ":" << second << " am" << std::endl;
	}
}

bool IsEarlierThan(const Time& t1, const Time& t2) {
	std::vector<int> at1;
	at1.push_back(t1.getHour());
	at1.push_back(t1.getMinute());
	at1.push_back(t1.getSecond());
	std::vector<int> at2;
	at2.push_back(t2.getHour());
	at2.push_back(t2.getMinute());
	at2.push_back(t2.getSecond());
	if(at1[0] > at2[0]) {
		return false;
	} else {
		if(at1[0] < at2[0]) {
			return true;
		} else {
			if(at1[1] > at2[1]) {
				return false;
			} else {
				if(at1[1] < at2[1]) {
					return true;
				} else {
					if(at1[2] > at2[2]) {
						return false;
					} else { 
						return true;
					}
				}
			}
		}
	}
	
	
}