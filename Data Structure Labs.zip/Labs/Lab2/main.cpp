#include "Time.h"
#include <iostream>
#include <vector>
#include <algorithm>

int main(){
	Time t1;
	t1.setHour(13);
	t1.setMinute(2);
	t1.setSecond(1);
	Time t2(5,30,59);
	Time t3(15,10,45);
	std::vector<Time> times;
	times.push_back(t1);
	times.push_back(t2);
	times.push_back(t3);
	sort(times.begin(), times.end(), IsEarlierThan);
	for(int i=0; i<times.size(); i++) {
		times[i].printAmPm();
	}
}