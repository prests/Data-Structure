#include <map>
#include <iostream>
#include <vector>
using namespace std;

void check1(map<int,int>& numbers){
	map<int,int>::iterator itr;
	int num = 0;
	vector<int> nums;
	for(itr = numbers.begin(); itr!=numbers.end(); ++itr){
		if(itr->second>num){
			num = itr->second;
			nums.clear();
			nums.push_back(itr->first);
		}
		else {
			if(itr->second==num){
				nums.push_back(itr->first);
			}
		}
	}
	for(int i=0; i<nums.size(); ++i){
		cout << nums[i] << endl;
	}
}
int main(){
	map<int,int> numbers;
	++numbers[19];
	++numbers[83];
	++numbers[-12];
	++numbers[83];
	++numbers[65];
	++numbers[19];
	++numbers[45];
	++numbers[-12];
	++numbers[45];
	++numbers[19];
	++numbers[45];
	check1(numbers);
	cout << endl;
	
	map<int, int>check2;
	vector<int> nums;
	nums.push_back(19);
	nums.push_back(83);
	nums.push_back(-12);
	nums.push_back(83);
	nums.push_back(65);
	nums.push_back(19);
	nums.push_back(45);
	nums.push_back(-12);
	nums.push_back(45);
	nums.push_back(19);
	nums.push_back(45);	
	for(int i=0; i<nums.size(); ++i){
		map<int, int>::iterator itr = check2.find(nums[i]);
		if(nums[i] == itr->first){
			++itr->second;
		} else{
			check2.insert(make_pair(nums[i],1));
		}
	}
	check1(check2);
	return 0;
}