// A simple "caller ID" program

#include <iostream>
#include <vector>
#include <string>
#include <map>
using namespace std;

// add a number, name pair to the phonebook
void add(vector<string> &phonebook, int number, string const& name) {
  phonebook[number] = name;
}

// given a phone number, determine who is calling
void identify(const vector<string> & phonebook, int number) {
  if (phonebook[number] == "UNASSIGNED") 
    cout << "unknown caller!" << endl;
  else 
    cout << phonebook[number] << " is calling!" << endl;
}

void identify_map(const map<int,string>& phone_numbers, int number){
	map<int,string>::const_iterator itr = phone_numbers.find(number);
	if(itr->first == number){
		cout << itr->second << " is calling!" << endl;
	} else {
		cout << "unkown caller!" << endl;
	}
}
int main() {
  // create the phonebook; initially all numbers are unassigned
  vector<string> phonebook(10000, "UNASSIGNED");

  // add several names to the phonebook
  add(phonebook, 1111, "fred");
  add(phonebook, 2222, "sally");
  add(phonebook, 3333, "george");

  // test the phonebook
  identify(phonebook, 2222);
  identify(phonebook, 4444);
  
  cout << endl;
  
  //Maps
  map<int,string>phone_numbers;
  phone_numbers[1111] = "fred";
  phone_numbers[2222] = "sally";
  phone_numbers[3333] = "geoge";
  
  identify_map(phone_numbers, 1111);
  identify_map(phone_numbers, 1111111);
  
}
