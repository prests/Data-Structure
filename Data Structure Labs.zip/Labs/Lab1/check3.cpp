#include <iostream>   // library for reading & writing from the console/keyboard
#include <cmath>      // library with the square root function & absolute value
#include <cstdlib>    // library with the exit function

int main() {
	std::cout << "Enter the total number of numbers." << std::endl;
	int num_nums;
	std::cin >> num_nums;
	int i = 0;
	std::cout << "Enter a numbers." << std::endl;
	int arr[num_nums];
	while(i<num_nums) {
		int temp;
		std::cin >> temp;
		arr[i] = temp;
		i++;
	}
	int sum = 0;
	for(int i=0; i<num_nums; i++) {
		sum = sum + arr[i];
	}
	float avg = sum/num_nums;
	std::cout << "Average :" << avg << std::endl;
	std::cout << "Numbers less than Average:" << std::endl;
	for(int i=0; i<num_nums; i++) {
		if(arr[i]<avg) {
			std::cout << arr[i] << std::endl;
		}
	}
}