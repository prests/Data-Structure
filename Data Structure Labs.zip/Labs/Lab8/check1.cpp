#include <iostream>
using namespace std;

void freeboard(int& paths, int x, int y){
	if(x==0 && y==0) {
		++paths;
		return; 
	}
	if(x==0){
		freeboard(paths, x, y-1);
	} else {
		if(y==0){
			freeboard(paths, x-1, y);
		} else {
				freeboard(paths, x-1, y);
				freeboard(paths, x, y-1);
		}
	}
}

int main(){
	int x = 2;
	int y = 2;
	int paths = 0;
	freeboard(paths, x, y);
	cout << paths << endl;
}