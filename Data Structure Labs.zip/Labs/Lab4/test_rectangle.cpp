#include "Rectangle.h"
#include <iostream>
#include <vector>

int main(){
	Point2D pt (0,0);
	Point2D p1 (0,0);
	Point2D p2 (2,2);
	Point2D p3 (1,1);
	Point2D p4 (6,4);
	Rectangle r1 (p1,p2);
	Rectangle r2 (p3,p4);
	r1.add_point(p1);
	r1.add_point(p2);
	r2.add_point(p3);
	r2.add_point(p4);
	Point2D up_right = r1.upper_right_corner();
	std::cout << "upper right " << up_right.x() << ',' << up_right.y() << std::endl;
	Point2D low_left = r1.lower_left_corner();
	std::cout << "low left " << low_left.x() << ',' << low_left.y() << std::endl;
	r2.upper_right_corner();
	r2.lower_left_corner();
	std::cout<< r1.is_point_within(p1) << std::endl;
	std::cout<< r1.is_point_within(p4) << std::endl;
	std::cout<< r2.is_point_within(p3) << std::endl;
	std::cout<< r2.is_point_within(p1) << std::endl;
	std::vector<Point2D> a = points_in_both(r1,r2);
	for(int i=0; i<a.size(); ++i){
		std::cout << a[i].x() << ',' << a[i].y() << std::endl;
	}
	pt.set(3,3);
}