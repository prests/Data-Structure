#ifndef superhero_h_
#define superhero_h_

#include <string>
#include <iostream>

class Superhero{
	private:
		std::string Supername;
		std::string Realname;
		std::string Power;
		bool good;
	public:
		Superhero(std::string aSuperName, std::string aName, std::string aPower) : Supername(aSuperName), Realname(aName), Power(aPower), good(true) {}
		std::string getName() const { return Supername;}
		std::string getPower() const { return Power;}
		std::string getTrueIdentity() const { return Realname; }
		bool isGood() const { return good; }
		bool operator== (const std::string aName) const{ return Realname == aName; }
		bool operator!= (const std::string aName) const{ return Realname != aName; }
		void operator- () { 
			if(good) { good = false;}
			else { good = true;} 
		}
		bool operator> (const Superhero super) const{
			if(super.getPower() == "Water"){
				if(Power == "Fire")
					return false;
				else
					return true;
			}
			if(super.getPower() == "Fire"){
				if(Power == "Wood")
					return false;
				else
					return true;
			}
			if(super.getPower() == "Wood"){
				if(Power == "Water")
					return false;
				else
					return true;
			}
		}
};

inline std::ostream& operator<<(std::ostream &ostr, const Superhero &super){
	ostr << "Superhero " << super.getName() << " has power " << super.getPower() << std::endl;
	return ostr;
}

#endif