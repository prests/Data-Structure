#include <vector>
#include <list>
#include <iostream>
using namespace std;

void print_vector(vector<int> vec){
	cout << "Size: " << vec.size() << endl;
	cout << "Vector: ";
	for(int i=0; i<vec.size(); ++i){
		cout << vec[i] << " ";
	}
	cout << endl;
}

void print_list(list<int> lis){
	cout << "Size: " << lis.size() << endl;
	cout << "List: ";
	list<int>::const_iterator it;
	for(it = lis.begin(); it != lis.end(); ++it){
		cout << *it << " ";
	}
	cout << endl;
}

void reverse_vector(vector<int> &old){
	if(old.size() == 0 ||  old.size()==1){ return;}
	int j = 0;
	for(int i=old.size()-1; i>=old.size()/2; --i){
		int temp = old[i];
		old[i] = old[j];
		old[j] = temp;
		++j;
	}	
}

void reverse_list(list<int> &old){
	if(old.size() == 0 || old.size() == 1){ return;}
	list<int>::iterator it;
	list<int>::reverse_iterator r_it;
	int count;
	for(r_it = old.rbegin(), it = old.begin(), count = 0; count<old.size()/2; ++r_it){
		int temp = *it;
		*it = *r_it;
		*r_it = temp;
		++it;
		++count;
	}
}
int main(){
	//test vectors
	//normal test
	vector<int> a;
	for(int i=0; i<10; ++i) a.push_back(i*i);
	print_vector(a);
	reverse_vector(a);
	print_vector(a);
	cout << endl;
	//size == 0
	vector<int> c;
	print_vector(c);
	reverse_vector(c);
	print_vector(c);
	cout << endl;
	//size == 1
	vector<int> e;
	e.push_back(1);
	print_vector(e);
	reverse_vector(e);
	print_vector(e);
	cout << endl;
	//size == 2
	vector<int> g;
	g.push_back(1);
	g.push_back(2);
	print_vector(g);
	reverse_vector(g);
	print_vector(g);
	cout<< endl;
	
	//test lists
	//normal test
	list<int> j;
	for(int i=0; i<10; ++i) j.push_back(i*i);
	print_list(j);
	reverse_list(j);
	print_list(j);
	cout << endl;
	//size == 0
	list<int> l;
	print_list(l);
	reverse_list(l);
	print_list(l);
	cout << endl;
	//size == 1
	list<int> n;
	n.push_back(1);
	print_list(n);
	reverse_list(n);
	print_list(n);
	cout << endl;
	//size == 2
	list<int> p;
	p.push_back(1);
	p.push_back(2);
	print_list(p);
	reverse_list(p);
	print_list(p);
	cout<< endl;
}