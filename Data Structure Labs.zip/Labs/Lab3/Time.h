#include <iostream>
#include <vector>
#include <algorithm>

class Time {

public:
	Time();
	Time(uintptr_t aHour, uintptr_t aMinute, uintptr_t aSecond);
	
	// ACCESSORS
	uintptr_t getHour() const;
	uintptr_t getMinute() const;
	uintptr_t getSecond() const;
	// MUTATORS
	void setHour(uintptr_t newHour);
	void setMinute(uintptr_t newMinute);
	void setSecond(uintptr_t newSecond);
	// METHODS
	void pruintptr_tAmPm();
	
private:
	uintptr_t hour;
	uintptr_t minute;
	uintptr_t second;
		
};

bool IsEarlierThan(const Time& t1, const Time& t2);