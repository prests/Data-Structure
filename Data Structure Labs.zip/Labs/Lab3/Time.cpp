#include "Time.h"
#include <iostream>
#include <vector>
#include <algorithm>

Time::Time(uintptr_t aHour, uintptr_t aMinute, uintptr_t aSecond) {
	hour = aHour;
	minute = aMinute;
	second = aSecond;
}

Time::Time() {
	hour = 0;
	minute = 0;
	second = 0;
}

uintptr_t Time::getHour() const {
	return hour;
}

uintptr_t Time::getMinute() const {
	return minute;
}

uintptr_t Time::getSecond() const {
	return second;
}

void Time::setHour(uintptr_t newHour) {
	hour = newHour;
}

void Time::setMinute(uintptr_t newMinute) {
	minute = newMinute;
}

void Time::setSecond(uintptr_t newSecond) {
	second = newSecond;
}

void Time::pruintptr_tAmPm() {
	if(hour >= 12){
		std::cout << hour%12 << ":" << minute << ":" << second << " pm" << std::endl;
	} else {
		std::cout << hour << ":" << minute << ":" << second << " am" << std::endl;
	}
}

bool IsEarlierThan(const Time& t1, const Time& t2) {
	std::vector<uintptr_t> at1;
	at1.push_back(t1.getHour());
	at1.push_back(t1.getMinute());
	at1.push_back(t1.getSecond());
	std::vector<uintptr_t> at2;
	at2.push_back(t2.getHour());
	at2.push_back(t2.getMinute());
	at2.push_back(t2.getSecond());
	if(at1[0] > at2[0]) {
		return false;
	} else {
		if(at1[0] < at2[0]) {
			return true;
		} else {
			if(at1[1] > at2[1]) {
				return false;
			} else {
				if(at1[1] < at2[1]) {
					return true;
				} else {
					if(at1[2] > at2[2]) {
						return false;
					} else { 
						return true;
					}
				}
			}
		}
	}
}