#include <cstdio>
#include <iostream>
#include <cassert>
#include <cstdlib>
#include <stdint.h>
#include <vector>
#include <iomanip>
#include <string>

using namespace std;

void compute_squares(int a[], int b[], int n) {
	for (int i = 0; i < n; ++i) {
		*(b + i) = *(a + i) * *(a + i);
	}
}

int main(){
	int n =3;
	int a[n]= {1,2,3};
	int b[n];
	compute_squares(a,b,n);
	for(int i=0; i<n; ++i){
		cout << b[i] << endl;
	}
	cout << endl;
	n =4;
	int c[n]= {1,2,3,4};
	int d[n];
	compute_squares(c,d,n);
	for(int i=0; i<n; ++i){
		cout << d[i] << endl;
	}
	cout << endl;
	n =5;
	int e[n]= {7,10,2,-1,4};
	int f[n];
	compute_squares(e,f,n);
	for(int i=0; i<n; ++i){
		cout << f[i] << endl;
	}
}