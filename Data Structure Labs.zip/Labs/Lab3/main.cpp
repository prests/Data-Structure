#include "Time.h"
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

Time change_times(Time &t1, Time t2){
	t1.setHour(14);
	t1.setMinute(30);
	t1.setSecond(0);
	t2.setHour(6);
	t2.setMinute(0);
	t2.setSecond(0);
	cout << sizeof(t1) << endl;
	cout << sizeof(t2) << endl;
	return t2;
}

int main(){
	Time t1(13,2,1);
	Time t2(5,30,59);
	uintptr_t a = sizeof(t1);
	Time t3 = change_times(t1,t2);
	cout << a << endl;
	cout << sizeof(t2) << endl;
	cout << sizeof(t3) << endl;
}